package BackEnd.service;

import BackEnd.connect.DBSqlConnection;
import BackEnd.model.NguoiDung;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Khang
 */
public class NguoiDungService {

    public ArrayList<NguoiDung> getAll() {
        ArrayList<NguoiDung> list = new ArrayList<>();

        String sql = "SELECT * FROM NguoiDung "
                + "JOIN ChucVu ON NguoiDung.ID_chucVu = ChucVu.ID_chucVu "
                + "ORDER BY NguoiDung.ngaySinh DESC"; // Hoặc tiêu chí khác nếu cần

        DBSqlConnection dbConnection = new DBSqlConnection();

        try (Connection cn = dbConnection.getConnect(); PreparedStatement pstm = cn.prepareStatement(sql); ResultSet rs = pstm.executeQuery()) {

            while (rs.next()) {
                NguoiDung nguoiDung = new NguoiDung();

                nguoiDung.setID_nhanVien(rs.getInt("ID_nhanVien"));
                nguoiDung.setIdChucVu(rs.getInt("ID_chucVu"));
                nguoiDung.setTenNguoiDung(rs.getString("tenNhanVien"));
                nguoiDung.setNgaySinh(rs.getString("ngaySinh"));
                nguoiDung.setSoDienThoai(rs.getString("soDienThoai"));
                nguoiDung.setEmail(rs.getString("email"));
                nguoiDung.setQueQuan(rs.getString("queQuan"));
                nguoiDung.setTrangThai(rs.getString("trangThai"));
                // Thêm đối tượng vào danh sách
                list.add(nguoiDung);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public Integer ADD(NguoiDung nd) {
        Integer row = null;
        String sql = "INSERT INTO NguoiDung (ID_ChucVu, tenNhanVien, NgaySinh, SoDienThoai, Email, QueQuan, TrangThai) VALUES (?, ?, ?, ?, ?, ?, ?)";
        DBSqlConnection dbConnection = new DBSqlConnection();

        try (Connection cn = dbConnection.getConnect(); PreparedStatement pstm = cn.prepareStatement(sql)) {

            // Gán giá trị cho các tham số trong câu lệnh SQL
            pstm.setInt(1, nd.getIdChucVu()); // ID Chức vụ
            pstm.setString(2, nd.getTenNguoiDung()); // Tên Người Dùng
            pstm.setString(3, nd.getNgaySinh()); // Ngày sinh
            pstm.setString(4, nd.getSoDienThoai()); // Số điện thoại
            pstm.setString(5, nd.getEmail()); // Email
            pstm.setString(6, nd.getQueQuan()); // Quê quán
            pstm.setString(7, nd.getTrangThai()); // Trạng thái

            // Thực thi câu lệnh INSERT và trả về số dòng đã được ảnh hưởng
            row = pstm.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace(); // In lỗi ra console để tiện theo dõi
        }

        return row;
    }

    public Integer update(NguoiDung kh) {
        Integer row = null;
        String sql = "UPDATE NguoiDung "
                + "SET tenNhanVien = ?, ngaySinh = ?, soDienThoai = ?, Email = ?, queQuan = ?, trangThai = ? "
                + "WHERE ID_nhanVien = ?";
        DBSqlConnection dbConnection = new DBSqlConnection();

        try (Connection cn = dbConnection.getConnect(); PreparedStatement pstm = cn.prepareStatement(sql)) {
            pstm.setString(1, kh.getTenNguoiDung());
            pstm.setString(2, kh.getNgaySinh());
            pstm.setString(3, kh.getSoDienThoai());
            pstm.setString(4, kh.getEmail());
            pstm.setString(5, kh.getQueQuan());
            pstm.setString(6, kh.getTrangThai());
            pstm.setInt(7, kh.getID_nhanVien());

            row = pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return row;
    }

//    public static void main(String[] args) {
//        // Tạo đối tượng NguoiDung
//        NguoiDung nguoiDung = new NguoiDung();
//        nguoiDung.setTenNguoiDung("Khang new");
//        nguoiDung.setNgaySinh("1990-05-20");
//        nguoiDung.setSoDienThoai("0123456789");
//        nguoiDung.setEmail("nguyenvana@gmail.com");
//        nguoiDung.setQueQuan("Ha Noi");
//        nguoiDung.setTrangThai("Active");
//        nguoiDung.setID_nhanVien(21); // ID của bản ghi cần cập nhật
//        
//        // Gọi phương thức update
//        NguoiDungService service = new NguoiDungService();
//        Integer result = service.update(nguoiDung);
//
//        // Kiểm tra kết quả
//        if (result != null && result > 0) {
//            System.out.println("Cập nhật thành công!");
//        } else {
//            System.out.println("Cập nhật thất bại!");
//        }
//    }
    public ArrayList<NguoiDung> locNguoiDung(String trangThai) {
        ArrayList<NguoiDung> listNguoiDung = new ArrayList<>();
        DBSqlConnection dbConnection = new DBSqlConnection();
        Connection cn = dbConnection.getConnect();  // Sử dụng kết nối từ DBSqlConnection

        // Câu lệnh SQL để lấy danh sách người dùng theo trạng thái
        String sql = "SELECT * FROM NguoiDung WHERE TrangThai = ?";

        try {
            if (cn != null) {  // Kiểm tra kết nối trước khi thực hiện câu lệnh SQL
                PreparedStatement ps = cn.prepareStatement(sql);
                ps.setString(1, trangThai);  // Thiết lập giá trị cho trạng thái

                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    // Tạo đối tượng NguoiDung từ dữ liệu trong ResultSet
                    NguoiDung nguoiDung = new NguoiDung();
                    nguoiDung.setID_nhanVien(rs.getInt("ID_nhanVien"));
                    nguoiDung.setIdChucVu(rs.getInt("ID_chucVu"));
                    nguoiDung.setTenNguoiDung(rs.getString("tenNhanVien"));
                    nguoiDung.setNgaySinh(rs.getString("ngaySinh"));
                    nguoiDung.setSoDienThoai(rs.getString("soDienThoai"));
                    nguoiDung.setEmail(rs.getString("email"));
                    nguoiDung.setQueQuan(rs.getString("queQuan"));
                    nguoiDung.setTrangThai(rs.getString("trangThai"));  // Lấy trạng thái từ CSDL

                    // Thêm đối tượng NguoiDung vào danh sách
                    listNguoiDung.add(nguoiDung);
                }
            } else {
                System.out.println("Kết nối đến cơ sở dữ liệu không thành công!");
            }
        } catch (Exception e) {
            System.out.println("Lỗi: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (cn != null && !cn.isClosed()) {
                    cn.close();  // Đảm bảo kết nối được đóng sau khi sử dụng
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return listNguoiDung;  // Trả về danh sách người dùng
    }

}
