/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BackEnd.service;

import BackEnd.connect.DBSqlConnection;
import BackEnd.entity.SanPhamChiTiet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Khang
 */
public class SanPhamChiTietService {
   public ArrayList<SanPhamChiTiet> getALLSanPhamChiTiet() {
    ArrayList<SanPhamChiTiet> listChiTietSanPham = new ArrayList<>();
    String sql = "SELECT CTSP.ID_chiTietSanPham, CTSP.ID_sanPham, CTSP.maSanPhamChiTiet, CTSP.soLuong, CTSP.giaBan, CTSP.trangThai, "
               + "KT.kichThuoc, MS.tenMau, CL.tenChatLieu "
               + "FROM ChiTietSanPham CTSP "
               + "LEFT JOIN KichThuoc KT ON CTSP.ID_kichThuoc = KT.ID_kichThuoc "
               + "LEFT JOIN MauSac MS ON CTSP.ID_mauSac = MS.ID_mauSac "
               + "LEFT JOIN ChatLieu CL ON CTSP.ID_chatLieu = CL.ID_chatLieu "
               + "ORDER BY CTSP.ID_chiTietSanPham ASC;";

    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql);
         ResultSet rs = pstm.executeQuery()) {

        while (rs.next()) {
            SanPhamChiTiet chiTietSanPham = new SanPhamChiTiet();
            chiTietSanPham.setIdChiTietSanPham(rs.getInt("ID_chiTietSanPham"));
            chiTietSanPham.setIdSanPham(rs.getInt("ID_sanPham"));
            chiTietSanPham.setMaSanPhamChiTiet(rs.getString("maSanPhamChiTiet"));
            chiTietSanPham.setSoLuong(rs.getInt("soLuong"));
            chiTietSanPham.setGiaBan(rs.getDouble("giaBan"));
            chiTietSanPham.setTrangThai(rs.getString("trangThai"));
            chiTietSanPham.setIdKichThuoc(rs.getInt("kichThuoc"));
            chiTietSanPham.setIdMauSac(rs.getInt("tenMau"));
            chiTietSanPham.setIdChatLieu(rs.getInt("tenChatLieu"));

            listChiTietSanPham.add(chiTietSanPham);
        }
    } catch (Exception e) {
        System.err.println("Lỗi khi lấy danh sách chi tiết sản phẩm: " + e.getMessage());
        e.printStackTrace();
    }
    return listChiTietSanPham;
}
   public static void main(String[] args) {
    try {
        SanPhamChiTietService chiTietSanPhamService = new SanPhamChiTietService();

        // Lấy danh sách tất cả chi tiết sản phẩm
        ArrayList<SanPhamChiTiet> danhSachChiTietSanPham = chiTietSanPhamService.getALLSanPhamChiTiet();

        if (Objects.nonNull(danhSachChiTietSanPham) && !danhSachChiTietSanPham.isEmpty()) {
            System.out.println("Danh sách chi tiết sản phẩm:");

            StringBuilder builder = new StringBuilder();
            for (SanPhamChiTiet ctsp : danhSachChiTietSanPham) {
                builder.append("ID Chi tiết sản phẩm: ").append(ctsp.getIdChiTietSanPham()).append("\n")
                       .append("ID Sản phẩm: ").append(ctsp.getIdSanPham()).append("\n")
                       .append("Mã sản phẩm chi tiết: ").append(ctsp.getMaSanPhamChiTiet()).append("\n")
                       .append("Số lượng: ").append(ctsp.getSoLuong()).append("\n")
                       .append("Giá bán: ").append(ctsp.getGiaBan()).append("\n")
                       .append("Trạng thái: ").append(ctsp.getTrangThai()).append("\n")
                       .append("Kích thước: ").append(ctsp.getIdKichThuoc()).append("\n")
                       .append("Màu sắc: ").append(ctsp.getIdMauSac()).append("\n")
                       .append("Chất liệu: ").append(ctsp.getIdChatLieu()).append("\n")
                       .append("--------------------------\n");
            }
            System.out.println(builder.toString());
        } else {
            System.out.println("Không có chi tiết sản phẩm nào trong danh sách.");
        }
    } catch (Exception e) {
        System.err.println("Lỗi trong quá trình lấy danh sách chi tiết sản phẩm: " + e.getMessage());
        e.printStackTrace();
    }
}


}
