/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BackEnd.service;

import BackEnd.connect.DBSqlConnection;
import BackEnd.entity.KhachHang;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Khang
 */
public class KhachHangService {
    public ArrayList<KhachHang> getAllKhachHang() {
    ArrayList<KhachHang> lst = new ArrayList<>();
    String sql = "SELECT * FROM KhachHang";
    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql);
         ResultSet rs = pstm.executeQuery()) {
        
        while (rs.next()) {
            KhachHang kh = new KhachHang();
            kh.setID_khachHang(rs.getInt("ID_khachHang"));
            kh.setMaKhachHang(rs.getString("maKhachHang"));
            kh.setHoVaTen(rs.getString("hoVaTen"));
            kh.setNgaySinh(rs.getString("ngaySinh"));
            kh.setGioiTinh(rs.getString("gioiTinh"));
            kh.setSoDienThoai(rs.getString("soDienThoai"));
            kh.setDiaChi(rs.getString("diaChi"));
            kh.setTrangThai(rs.getString("trangThai"));
            lst.add(kh);
        }
    } catch (SQLException e) {
        System.out.println("Error retrieving customers: " + e.getMessage());
    }
    return lst;
}


   public Integer updateKhachHang(KhachHang kh) {
    Integer row = null;
    String sql = "UPDATE KhachHang SET maKhachHang = ?, hoVaTen = ?, ngaySinh = ?, gioiTinh = ?, soDienThoai = ?, " +
                 "diaChi = ?, trangThai = ? WHERE ID_khachHang = ?";
    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql)) {
        
        pstm.setString(1, kh.getMaKhachHang());
        pstm.setString(2, kh.getHoVaTen());
        pstm.setString(3, kh.getNgaySinh());
        pstm.setString(4, kh.getGioiTinh());
        pstm.setString(5, kh.getSoDienThoai());
        pstm.setString(6, kh.getDiaChi());
        pstm.setString(7, kh.getTrangThai());
        pstm.setInt(8, kh.getID_khachHang());

        row = pstm.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Error updating customer: " + e.getMessage());
    }
    return row;
}


   public Integer addKhachHang(KhachHang kh) {
    Integer row = null;
    String sql = "INSERT INTO KhachHang (maKhachHang, hoVaTen, ngaySinh, gioiTinh, soDienThoai, diaChi, trangThai) " +
                 "VALUES (?, ?, ?, ?, ?, ?, ?)";
    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql)) {
        
        pstm.setString(1, kh.getMaKhachHang());
        pstm.setString(2, kh.getHoVaTen());
        pstm.setString(3, kh.getNgaySinh());
        pstm.setString(4, kh.getGioiTinh());
        pstm.setString(5, kh.getSoDienThoai());
        pstm.setString(6, kh.getDiaChi());
        pstm.setString(7, kh.getTrangThai());

        row = pstm.executeUpdate();
    } catch (SQLException e) {
        System.out.println("Error adding customer: " + e.getMessage());
    }
    return row;
}

   public static void main(String[] args) {
    KhachHangService khachHangService = new KhachHangService();

    // Lấy danh sách tất cả khách hàng
    ArrayList<KhachHang> danhSachKhachHang = khachHangService.getAllKhachHang();

    // Kiểm tra nếu danh sách không trống
    if (danhSachKhachHang != null && !danhSachKhachHang.isEmpty()) {
        System.out.println("Danh sách khách hàng:");
        for (KhachHang kh : danhSachKhachHang) {
            System.out.println("ID: " + kh.getID_khachHang());
            System.out.println("Mã khách hàng: " + kh.getMaKhachHang());
            System.out.println("Họ và tên: " + kh.getHoVaTen());
            System.out.println("Ngày sinh: " + kh.getNgaySinh());
            System.out.println("Giới tính: " + kh.getGioiTinh());
            System.out.println("Số điện thoại: " + kh.getSoDienThoai());
            System.out.println("Địa chỉ: " + kh.getDiaChi());
            System.out.println("Trạng thái: " + kh.getTrangThai());
            System.out.println("--------------------------");
        }
    } else {
        System.out.println("Không có khách hàng nào trong danh sách.");
    }
}

}
