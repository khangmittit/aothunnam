/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BackEnd.service;

import BackEnd.connect.DBSqlConnection;
import BackEnd.entity.SanPham;
import BackEnd.entity.ThuongHieu;
import BackEnd.entity.XuatXu;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Khang
 */
public class SanPhamService {
    public ArrayList<SanPham> getALLSp() {
    ArrayList<SanPham> listSanPham = new ArrayList<>();
    String sql = "SELECT SANPHAM.ID_sanPham, SANPHAM.maSanPham, SANPHAM.tenSanPham, SANPHAM.soLuong, SANPHAM.trangThai, "
               + "THUONGHIEU.tenThuongHieu, XUATXU.tenXuatXu "
               + "FROM SANPHAM "
               + "LEFT JOIN THUONGHIEU ON SANPHAM.ID_thuongHieu = THUONGHIEU.ID_thuongHieu "
               + "LEFT JOIN XUATXU ON SANPHAM.ID_xuatXu = XUATXU.ID_xuatXu "
               + "ORDER BY SANPHAM.tenSanPham ASC;";

    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql);
         ResultSet rs = pstm.executeQuery()) {

        while (rs.next()) {
            SanPham sanPham = new SanPham();
            sanPham.setIdSanPham(rs.getInt("ID_sanPham"));
            sanPham.setMaSanPham(rs.getString("maSanPham"));
            sanPham.setTenSanPham(rs.getString("tenSanPham"));
            sanPham.setSoLuong(rs.getInt("soLuong"));
            sanPham.setTrangThai(rs.getString("trangThai"));
            sanPham.setTenThuongHieu(rs.getString("tenThuongHieu"));
            sanPham.setTenXuatXu(rs.getString("tenXuatXu"));

            listSanPham.add(sanPham);
        }
    } catch (Exception e) {
        System.err.println("Lỗi khi lấy danh sách sản phẩm: " + e.getMessage());
        e.printStackTrace();
    }
    return listSanPham;
}
//    public static void main(String[] args) {
//        SanPhamService sanPhamService = new SanPhamService();
//
//        // Lấy danh sách tất cả sản phẩm
//        ArrayList<SanPham> danhSachSanPham = sanPhamService.getALLSp();
//
//        // Kiểm tra nếu danh sách không trống
//        if (danhSachSanPham != null && !danhSachSanPham.isEmpty()) {
//            System.out.println("Danh sách sản phẩm:");
//            for (SanPham sp : danhSachSanPham) {
//                System.out.println("ID: " + sp.getIdSanPham());
//                System.out.println("Mã sản phẩm: " + sp.getMaSanPham());
//                System.out.println("Tên sản phẩm: " + sp.getTenSanPham());
//                System.out.println("Số lượng: " + sp.getSoLuong());
//                System.out.println("Trạng thái: " + sp.getTrangThai());
//                System.out.println("Thương hiệu: " + sp.getTenThuongHieu()); // Hiển thị tên thương hiệu
//                System.out.println("Xuất xứ: " + sp.getTenXuatXu());         // Hiển thị tên xuất xứ
//                System.out.println("--------------------------");
//            }
//        } else {
//            System.out.println("Không có sản phẩm nào trong danh sách.");
//        }
//    }
    public ArrayList<SanPham> getSanPhamByMa(String ma) {
    ArrayList<SanPham> listsp = new ArrayList<>();
    if (ma == null || ma.trim().isEmpty()) {
        System.out.println("Mã sản phẩm không được để trống.");
        return listsp;
    }
    String sql = "SELECT SANPHAM.*, THUONGHIEU.tenThuongHieu, XUATXU.tenXuatXu \n" +
"    FROM SANPHAM\n" +
"    LEFT JOIN THUONGHIEU ON SANPHAM.ID_thuongHieu = THUONGHIEU.ID_thuongHieu\n" +
"    LEFT JOIN XUATXU ON SANPHAM.ID_xuatXu = XUATXU.ID_xuatXu\n" +
"    WHERE SANPHAM.maSanPham = ?";
    try (PreparedStatement ps = new DBSqlConnection().getConnect().prepareStatement(sql)) {
        ps.setString(1, ma);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int id = rs.getInt("ID_sanPham");
            int soLuong = rs.getInt("soLuong");
            String maSanPham = rs.getString("maSanPham");
            String tensp = rs.getString("tenSanPham");
            String tt = rs.getString("trangThai");
            String th = rs.getString("tenThuongHieu");
            String xx = rs.getString("tenXuatXu");

            listsp.add(new SanPham(id, maSanPham, tensp, soLuong, tt, th, xx));
        }
    } catch (Exception e) {
        System.out.println("Lỗi khi truy vấn sản phẩm theo mã: " + e.getMessage());
    }
    return listsp;
}
    public ArrayList<ThuongHieu> getThuongHieuFromDB() {
    ArrayList<ThuongHieu> thuongHieuList = new ArrayList<>();
    String sql = "SELECT ID_thuongHieu, tenThuongHieu FROM THUONGHIEU ORDER BY tenThuongHieu ASC";

    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql);
         ResultSet rs = pstm.executeQuery()) {

        while (rs.next()) {
            int id = rs.getInt("ID_thuongHieu");
            String tenThuongHieu = rs.getString("tenThuongHieu");

            // Tạo đối tượng ThuongHieu và thêm vào danh sách
            ThuongHieu thuongHieu = new ThuongHieu(id, tenThuongHieu);
            thuongHieuList.add(thuongHieu);
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi lấy dữ liệu Thương hiệu: " + e.getMessage());
        e.printStackTrace();
    }

    return thuongHieuList;
}

    
    public ArrayList<XuatXu> getXuatXuFromDB() {
    ArrayList<XuatXu> xuatXuList = new ArrayList<>();
    String sql = "SELECT ID_xuatXu, tenXuatXu FROM XUATXU ORDER BY tenXuatXu ASC";

    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql);
         ResultSet rs = pstm.executeQuery()) {

        while (rs.next()) {
            int id = rs.getInt("ID_xuatXu");
            String tenXuatXu = rs.getString("tenXuatXu");

            // Tạo đối tượng XuatXu và thêm vào danh sách
            XuatXu xuatXu = new XuatXu(id, tenXuatXu);
            xuatXuList.add(xuatXu);
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi lấy dữ liệu Xuất xứ: " + e.getMessage());
        e.printStackTrace();
    }

    return xuatXuList;
}

    public ArrayList<SanPham> getFilteredSanPham(String thuongHieu, String xuatXu) {
    ArrayList<SanPham> filteredList = new ArrayList<>();
    StringBuilder sql = new StringBuilder("SELECT SANPHAM.ID_sanPham, SANPHAM.maSanPham, SANPHAM.tenSanPham, SANPHAM.soLuong, SANPHAM.trangThai, "
                                        + "THUONGHIEU.tenThuongHieu, XUATXU.tenXuatXu "
                                        + "FROM SANPHAM "
                                        + "LEFT JOIN THUONGHIEU ON SANPHAM.ID_thuongHieu = THUONGHIEU.ID_thuongHieu "
                                        + "LEFT JOIN XUATXU ON SANPHAM.ID_xuatXu = XUATXU.ID_xuatXu "
                                        + "WHERE 1=1 ");  // Điều kiện mặc định luôn đúng

    // Thêm điều kiện lọc nếu có
    if (!thuongHieu.isEmpty()) {
        sql.append("AND THUONGHIEU.tenThuongHieu = ? ");
    }
    if (!xuatXu.isEmpty()) {
        sql.append("AND XUATXU.tenXuatXu = ? ");
    }

    // Thực thi truy vấn
    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql.toString())) {

        int index = 1;

        // Thêm giá trị tham số vào câu truy vấn
        if (!thuongHieu.isEmpty()) {
            pstm.setString(index++, thuongHieu);
        }
        if (!xuatXu.isEmpty()) {
            pstm.setString(index++, xuatXu);
        }

        try (ResultSet rs = pstm.executeQuery()) {
            while (rs.next()) {
                SanPham sanPham = new SanPham();
                sanPham.setIdSanPham(rs.getInt("ID_sanPham"));
                sanPham.setMaSanPham(rs.getString("maSanPham"));
                sanPham.setTenSanPham(rs.getString("tenSanPham"));
                sanPham.setSoLuong(rs.getInt("soLuong"));
                sanPham.setTrangThai(rs.getString("trangThai"));
                sanPham.setTenThuongHieu(rs.getString("tenThuongHieu"));
                sanPham.setTenXuatXu(rs.getString("tenXuatXu"));
                filteredList.add(sanPham);
            }
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi lấy dữ liệu đã lọc: " + e.getMessage());
        e.printStackTrace();
    }
    return filteredList;
}

// Phương thức lấy dữ liệu Thương hiệu từ cơ sở dữ liệu
public ArrayList<String> getThuongHieuFromDBloc() {
    ArrayList<String> thuongHieuList = new ArrayList<>();
    String sql = "SELECT tenThuongHieu FROM THUONGHIEU ORDER BY tenThuongHieu ASC";
    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql);
         ResultSet rs = pstm.executeQuery()) {

        while (rs.next()) {
            thuongHieuList.add(rs.getString("tenThuongHieu"));
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi lấy dữ liệu Thương hiệu: " + e.getMessage());
        e.printStackTrace();
    }
    return thuongHieuList;
}

// Phương thức lấy dữ liệu Xuất xứ từ cơ sở dữ liệu
public ArrayList<String> getXuatXuFromDBloc() {
    ArrayList<String> xuatXuList = new ArrayList<>();
    String sql = "SELECT tenXuatXu FROM XUATXU ORDER BY tenXuatXu ASC";
    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql);
         ResultSet rs = pstm.executeQuery()) {

        while (rs.next()) {
            xuatXuList.add(rs.getString("tenXuatXu"));
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi lấy dữ liệu Xuất xứ: " + e.getMessage());
        e.printStackTrace();
    }
    return xuatXuList;
}

// Phương thức lọc sản phẩm theo thương hiệu
public ArrayList<SanPham> getSanPhamByThuongHieu(String tenThuongHieu) {
    ArrayList<SanPham> listSanPham = new ArrayList<>();
    String sql = "SELECT SANPHAM.ID_sanPham, SANPHAM.maSanPham, SANPHAM.tenSanPham, SANPHAM.soLuong, SANPHAM.trangThai, "
               + "THUONGHIEU.tenThuongHieu, XUATXU.tenXuatXu "
               + "FROM SANPHAM "
               + "LEFT JOIN THUONGHIEU ON SANPHAM.ID_thuongHieu = THUONGHIEU.ID_thuongHieu "
               + "LEFT JOIN XUATXU ON SANPHAM.ID_xuatXu = XUATXU.ID_xuatXu "
               + "WHERE THUONGHIEU.tenThuongHieu = ? "
               + "ORDER BY SANPHAM.tenSanPham ASC";
    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql)) {

        pstm.setString(1, tenThuongHieu); // Gán tham số cho câu lệnh SQL
        ResultSet rs = pstm.executeQuery();

        while (rs.next()) {
            SanPham sanPham = new SanPham();
            sanPham.setIdSanPham(rs.getInt("ID_sanPham"));
            sanPham.setMaSanPham(rs.getString("maSanPham"));
            sanPham.setTenSanPham(rs.getString("tenSanPham"));
            sanPham.setSoLuong(rs.getInt("soLuong"));
            sanPham.setTrangThai(rs.getString("trangThai"));
            sanPham.setTenThuongHieu(rs.getString("tenThuongHieu"));
            sanPham.setTenXuatXu(rs.getString("tenXuatXu"));

            listSanPham.add(sanPham);
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi lọc sản phẩm theo thương hiệu: " + e.getMessage());
        e.printStackTrace();
    }
    return listSanPham;
}



//public static void main(String[] args) {
//    SanPhamService sanPhamService = new SanPhamService();
//
//    // Nhập mã sản phẩm từ người dùng
//    String ma = "SP001"; // Hoặc nhận giá trị từ Scanner nếu cần
//
//    // Lấy danh sách sản phẩm theo mã
//    ArrayList<SanPham> danhSachSanPhamId = sanPhamService.getSanPhamByMa(ma);
//
//    // Kiểm tra nếu danh sách không trống
//    if (danhSachSanPhamId != null && !danhSachSanPhamId.isEmpty()) {
//        System.out.println("Danh sách sản phẩm:");
//        for (SanPham sp : danhSachSanPhamId) {
//            System.out.println(String.format("""
//                    ID: %d
//                    Mã sản phẩm: %s
//                    Tên sản phẩm: %s
//                    Số lượng: %d
//                    Trạng thái: %s
//                    Thương hiệu: %s
//                    Xuất xứ: %s
//                    --------------------------""",
//                    sp.getIdSanPham(),
//                    sp.getMaSanPham(),
//                    sp.getTenSanPham(),
//                    sp.getSoLuong(),
//                    sp.getTrangThai(),
//                    sp.getTenThuongHieu(),
//                    sp.getTenXuatXu()));
//        }
//    } else {
//        System.out.println("Không tìm thấy sản phẩm nào với mã: " + ma);
//    }
//}
public boolean isMaSanPhamExist(String maSanPham) {
    String sql = "SELECT COUNT(*) FROM SANPHAM WHERE maSanPham = ?";
    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql)) {

        pstm.setString(1, maSanPham);
        ResultSet rs = pstm.executeQuery();

        if (rs.next()) {
            return rs.getInt(1) > 0; // Nếu có sản phẩm có mã này, trả về true
        }

    } catch (SQLException e) {
        System.err.println("Lỗi khi kiểm tra mã sản phẩm: " + e.getMessage());
        e.printStackTrace();
    }

    return false;
}

public String generateNewMaSanPham() {
    String sql = "SELECT MAX(CAST(SUBSTRING(maSanPham, 3) AS UNSIGNED)) AS maxMa FROM SANPHAM";
    int maxMa = 0;

    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql);
         ResultSet rs = pstm.executeQuery()) {

        if (rs.next()) {
            maxMa = rs.getInt("maxMa");
        }

    } catch (SQLException e) {
        System.err.println("Lỗi khi lấy mã sản phẩm: " + e.getMessage());
        e.printStackTrace();
    }

    // Tạo mã mới theo cú pháp SP001, SP002, ...
    String newMaSanPham = String.format("SP%03d", maxMa + 1);

    // Kiểm tra mã sản phẩm có tồn tại không
    while (isMaSanPhamExist(newMaSanPham)) {
        maxMa++; // Tăng giá trị mã sản phẩm
        newMaSanPham = String.format("SP%03d", maxMa);
    }

    return newMaSanPham;
}


public boolean themSanPham(SanPham sanPham) {
    String sql = "INSERT INTO SANPHAM (maSanPham, tenSanPham, soLuong, tenThuongHieu, tenXuatXu) "
               + "VALUES (?, ?, ?, ?, ?)";
    try (Connection cn = new DBSqlConnection().getConnect();
         PreparedStatement pstm = cn.prepareStatement(sql)) {
        
        pstm.setString(1, sanPham.getMaSanPham());
        pstm.setString(2, sanPham.getTenSanPham());
        pstm.setInt(3, sanPham.getSoLuong());
        pstm.setString(4, sanPham.getTenThuongHieu());
        pstm.setString(5, sanPham.getTenXuatXu());

        int result = pstm.executeUpdate();
        return result > 0; // Nếu kết quả > 0, tức là thêm thành công
    } catch (SQLException e) {
        System.err.println("Lỗi khi thêm sản phẩm: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}

}
