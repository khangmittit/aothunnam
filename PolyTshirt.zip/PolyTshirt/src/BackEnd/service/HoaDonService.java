/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BackEnd.service;

import BackEnd.connect.DBSqlConnection;
import BackEnd.entity.*;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author Thien
 */
public class HoaDonService {

    public ArrayList<HoaDon> getAll() {
        ArrayList<HoaDon> list = new ArrayList<>();
        DBSqlConnection dbConnection = new DBSqlConnection();

        // Cập nhật câu lệnh SQL với JOIN các bảng liên quan để lấy thông tin đầy đủ
        String sql = "SELECT * FROM HOADON "
                + "JOIN KhachHang ON HOADON.ID_khachHang = KhachHang.ID_khachHang "
                + "JOIN NguoiDung ON HOADON.ID_nhanVien = NguoiDung.ID_nhanVien "
                + "JOIN Voucher ON HOADON.ID_voucher = Voucher.ID_voucher "
                + "ORDER BY HOADON.ngayTao DESC";  // Thêm ORDER BY hoặc sắp xếp theo tiêu chí khác nếu cần

        try (Connection cn = dbConnection.getConnect(); PreparedStatement pstm = cn.prepareStatement(sql); ResultSet rs = pstm.executeQuery()) {

            while (rs.next()) {
                // Tạo đối tượng HoaDon và ánh xạ dữ liệu từ ResultSet
                HoaDon hoaDon = new HoaDon();

                hoaDon.setID_hoaDon(rs.getInt("ID_hoaDon"));  // ID hóa đơn
                hoaDon.setID_nhanVien(rs.getInt("ID_nhanVien"));  // ID nhân viên
                hoaDon.setID_khachHang(rs.getInt("ID_khachHang"));  // ID khách hàng
                hoaDon.setID_vouCher(rs.getInt("ID_voucher"));  // ID voucher
                hoaDon.setNgayTao(rs.getDate("ngayTao"));  // Ngày tạo hóa đơn

                // Cập nhật kiểu dữ liệu cho các trường tongTien và soTienGiam (BigDecimal hoặc Double)
                hoaDon.setTongTien(rs.getBigDecimal("tongTien").toString());  // Tổng tiền (dạng String)
                hoaDon.setSoTienGiam(rs.getBigDecimal("soTienGiam").toString());  // Số tiền giảm (dạng String)

                hoaDon.setTenKhachHang(rs.getString("tenKhachHang"));  // Tên khách hàng
                hoaDon.setSoDienThoaiKhachHang(rs.getString("soDienThoaiKhachHang"));  // Số điện thoại khách hàng
                hoaDon.setTenNhanVien(rs.getString("tenNhanVien"));  // Tên nhân viên
                hoaDon.setTrangThai(rs.getString("trangThai"));  // Tên nhân viên

                // Thêm đối tượng vào danh sách
                list.add(hoaDon);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public HoaDon findById(int maHoaDon) {
        String sql = "SELECT * FROM HoaDon WHERE ID_hoaDon = ?";
        try {
            Connection connection = new DBSqlConnection().getConnect();
            if (connection != null) {
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setInt(1, maHoaDon);  // Set parameter for ID_hoaDon
                ResultSet rs = preparedStatement.executeQuery();

                if (rs.next()) {
                    int id = rs.getInt("ID_hoaDon");
                    int idKhachHang = rs.getInt("ID_khachHang");
                    int idNhanVien = rs.getInt("ID_nhanVien");
                    int idVoucher = rs.getInt("ID_voucher");
                    Date ngayTao = rs.getDate("ngayTao");
                    String tongTien = rs.getBigDecimal("tongTien").toString();
                    String tenKhachHang = rs.getString("tenKhachHang");
                    String soDienThoaiKhachHang = rs.getString("soDienThoaiKhachHang");
                    String tenNhanVien = rs.getString("tenNhanVien");
                    String trangThai = rs.getString("trangThai");
                    String soTienGiam = rs.getBigDecimal("soTienGiam").toString();

                    HoaDon hoaDon = new HoaDon(id, idKhachHang, idNhanVien, idVoucher, ngayTao, tongTien, tenKhachHang, soDienThoaiKhachHang, tenNhanVien, trangThai, soTienGiam);
                    return hoaDon;
                }
                rs.close();
                preparedStatement.close();
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi truy vấn dữ liệu: " + e.getMessage());
            e.printStackTrace(System.out);
        }
        return null;
    }

    public ArrayList<HoaDon> locHoaDonTheoTrangThai(String tt) {
        ArrayList<HoaDon> listL = new ArrayList<>();
        Connection cn = new DBSqlConnection().getConnect();
        String sql = "SELECT * FROM HoaDon WHERE TrangThai = ?";  // Chỉ lọc theo TrangThai
        try {
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, tt);  // Set giá trị cho TrangThai
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                // Lấy dữ liệu từ ResultSet và gán vào đối tượng HoaDon
                int id = rs.getInt("ID_hoaDon");
                int idKhachHang = rs.getInt("ID_khachHang");
                int idNhanVien = rs.getInt("ID_nhanVien");
                int idVoucher = rs.getInt("ID_vouCher");
                Date ngayTao = rs.getDate("ngayTao");
                String tongTien = rs.getBigDecimal("tongTien").toString(); // Lấy giá trị tổng tiền
                String tenKhachHang = rs.getString("tenKhachHang");
                String soDienThoaiKhachHang = rs.getString("soDienThoaiKhachHang");
                String tenNhanVien = rs.getString("tenNhanVien");
                String trangThai = rs.getString("trangThai");
                String soTienGiam = rs.getBigDecimal("soTienGiam").toString(); // Lấy giá trị số tiền giảm

                // Thêm đối tượng HoaDon vào danh sách
                HoaDon hoaDon = new HoaDon(id, idKhachHang, idNhanVien, idVoucher, ngayTao, tongTien,
                        tenKhachHang, soDienThoaiKhachHang, tenNhanVien, trangThai, soTienGiam);
                listL.add(hoaDon);
            }
        } catch (Exception e) {
            System.out.println("Lỗi khi lọc hóa đơn theo trạng thái: " + e);
        }
        return listL;
    }

    public ArrayList<HoaDonChiTiet> lienKetHoaDon(int id) {
        ArrayList<HoaDonChiTiet> listCT = new ArrayList<>();
        Connection cn = new DBSqlConnection().getConnect();
        String sql = "SELECT * FROM hoadonchitiet WHERE hoadonchitiet.ID_hoaDon = ?";

        try {
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setInt(1, id);  // Gán ID hóa đơn vào câu truy vấn
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                // Tạo đối tượng HoaDonChiTiet từ kết quả truy vấn
                int idHoaDonChiTiet = rs.getInt("ID_hoaDonChiTiet");
                int idHoaDon = rs.getInt("ID_hoaDon");
                String tenSanPham = rs.getString("tenSanPham");
                int soLuong = rs.getInt("soLuong");
                String giaBan = rs.getString("giaBan"); // Đảm bảo rằng giá được lưu dưới dạng String
                int idSanPhamChiTiet = rs.getInt("ID_sanPhamChiTiet");

                // Thêm đối tượng HoaDonChiTiet vào danh sách
                listCT.add(new HoaDonChiTiet(idHoaDonChiTiet, idHoaDon, tenSanPham, soLuong, giaBan, idSanPhamChiTiet));
            }

        } catch (Exception e) {
            System.out.println("Loi: " + e);
        }

        return listCT;
    }

}
