/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BackEnd.entity;

/**
 *
 * @author Khang
 */
public class HoaDonChiTiet {
    private int ID_hoaDonChiTiet;
    private int ID_HoaDon;
    private String tenSanPham;
    private int soLuong;
    private String giaBan;
    private int ID_sanPhamChiTiet;

    public HoaDonChiTiet() {
    }

    public HoaDonChiTiet(int ID_hoaDonChiTiet, int ID_HoaDon, String tenSanPham, int soLuong, String giaBan, int ID_sanPhamChiTiet) {
        this.ID_hoaDonChiTiet = ID_hoaDonChiTiet;
        this.ID_HoaDon = ID_HoaDon;
        this.tenSanPham = tenSanPham;
        this.soLuong = soLuong;
        this.giaBan = giaBan;
        this.ID_sanPhamChiTiet = ID_sanPhamChiTiet;
    }

    public int getID_hoaDonChiTiet() {
        return ID_hoaDonChiTiet;
    }

    public void setID_hoaDonChiTiet(int ID_hoaDonChiTiet) {
        this.ID_hoaDonChiTiet = ID_hoaDonChiTiet;
    }

    public int getID_HoaDon() {
        return ID_HoaDon;
    }

    public void setID_HoaDon(int ID_HoaDon) {
        this.ID_HoaDon = ID_HoaDon;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public String getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(String giaBan) {
        this.giaBan = giaBan;
    }

    public int getID_sanPhamChiTiet() {
        return ID_sanPhamChiTiet;
    }

    public void setID_sanPhamChiTiet(int ID_sanPhamChiTiet) {
        this.ID_sanPhamChiTiet = ID_sanPhamChiTiet;
    }
    
}
