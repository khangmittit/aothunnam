/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BackEnd.entity;

/**
 *
 * @author Khang
 */
public class XuatXu {
    private Integer idXuatXu; // Sửa thành Integer để hỗ trợ giá trị null
    private String tenXuatXu;

    // Constructor không tham số
    public XuatXu() {}

    // Constructor có tham số
    public XuatXu(Integer idXuatXu, String tenXuatXu) {
        this.idXuatXu = idXuatXu;
        this.tenXuatXu = tenXuatXu;
    }

    // Getter và Setter
    public Integer getIdXuatXu() {
        return idXuatXu;
    }

    public void setIdXuatXu(Integer idXuatXu) {
        this.idXuatXu = idXuatXu;
    }

    public String getTenXuatXu() {
        return tenXuatXu;
    }

    public void setTenXuatXu(String tenXuatXu) {
        this.tenXuatXu = tenXuatXu;
    }

    @Override
    public String toString() {
        return "XuatXu{" + "idXuatXu=" + idXuatXu + ", tenXuatXu='" + tenXuatXu + '\'' + '}';
    }
}


