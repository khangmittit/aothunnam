/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BackEnd.entity;

/**
 *
 * @author Khang
 */
public class KichThuoc {
    private int idKichThuoc;
    private String kichThuoc;

    // Getters and Setters
    public int getIdKichThuoc() {
        return idKichThuoc;
    }

    public void setIdKichThuoc(int idKichThuoc) {
        this.idKichThuoc = idKichThuoc;
    }

    public String getKichThuoc() {
        return kichThuoc;
    }

    public void setKichThuoc(String kichThuoc) {
        this.kichThuoc = kichThuoc;
    }

    @Override
    public String toString() {
        return "KichThuoc{" + "idKichThuoc=" + idKichThuoc + ", kichThuoc=" + kichThuoc + '}';
    }
    
}

