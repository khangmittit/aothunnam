package BackEnd.model;

import java.sql.Date;

public class NguoiDung {
    private int ID_nhanVien ;
    private int idChucVu;
    private String tenNguoiDung;
    private String ngaySinh;
    private String soDienThoai;
    private String email;
    private String queQuan;
    private String trangThai;  // Kiểu String để tương thích với DB

    // Constructor
    public NguoiDung(int ID_nhanVien , int idChucVu, int idVaiTro, String tenNguoiDung, String ngaySinh, String soDienThoai, String email, String queQuan, String trangThai) {
        this.ID_nhanVien  = ID_nhanVien ;
        this.idChucVu = idChucVu;
        this.tenNguoiDung = tenNguoiDung;
        this.ngaySinh = ngaySinh;
        this.soDienThoai = soDienThoai;
        this.email = email;
        this.queQuan = queQuan;
        this.trangThai = trangThai;
    }

    public NguoiDung() {
    }

    public int getIdChucVu() {
        return idChucVu;
    }

    public void setIdChucVu(int idChucVu) {
        this.idChucVu = idChucVu;
    }

    public String getTenNguoiDung() {
        return tenNguoiDung;
    }

    public void setTenNguoiDung(String tenNguoiDung) {
        this.tenNguoiDung = tenNguoiDung;
    }

    public String getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getQueQuan() {
        return queQuan;
    }

    public void setQueQuan(String queQuan) {
        this.queQuan = queQuan;
    }
    
    public int getID_nhanVien() {
        return ID_nhanVien;
    }

    // Getters và Setters cho các thuộc tính khác
    public void setID_nhanVien(int ID_nhanVien) {    
        this.ID_nhanVien = ID_nhanVien;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }
}
