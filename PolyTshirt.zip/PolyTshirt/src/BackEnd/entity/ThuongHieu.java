/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BackEnd.entity;

/**
 *
 * @author Khang
 */
public class ThuongHieu {
    private Integer idThuongHieu; // Sửa thành Integer để hỗ trợ giá trị null
    private String tenThuongHieu;

    // Constructor không tham số
    public ThuongHieu() {}

    // Constructor có tham số
    public ThuongHieu(Integer idThuongHieu, String tenThuongHieu) {
        this.idThuongHieu = idThuongHieu;
        this.tenThuongHieu = tenThuongHieu;
    }

    // Getter và Setter
    public Integer getIdThuongHieu() {
        return idThuongHieu;
    }

    public void setIdThuongHieu(Integer idThuongHieu) {
        this.idThuongHieu = idThuongHieu;
    }

    public String getTenThuongHieu() {
        return tenThuongHieu;
    }

    public void setTenThuongHieu(String tenThuongHieu) {
        this.tenThuongHieu = tenThuongHieu;
    }

    @Override
    public String toString() {
        return "ThuongHieu{" + "idThuongHieu=" + idThuongHieu + ", tenThuongHieu='" + tenThuongHieu + '\'' + '}';
    }
}


