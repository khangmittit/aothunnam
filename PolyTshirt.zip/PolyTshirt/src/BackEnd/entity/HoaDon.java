/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BackEnd.entity;

import java.util.Date;

/**
 *
 * @author Khang
 */
public class HoaDon {
    private int ID_hoaDon;
    private int ID_khachHang;
    private int ID_nhanVien;
    private int ID_vouCher;
    private Date ngayTao;
    private String tongTien;
    private String tenKhachHang;
    private String soDienThoaiKhachHang;
    private String tenNhanVien;
    private String trangThai;
    private String soTienGiam;

    public HoaDon() {
    }

    public HoaDon(int ID_hoaDon, int ID_khachHang, int ID_nhanVien, int ID_vouCher, Date ngayTao, String tongTien, String tenKhachHang, String soDienThoaiKhachHang, String tenNhanVien, String trangThai, String soTienGiam) {
        this.ID_hoaDon = ID_hoaDon;
        this.ID_khachHang = ID_khachHang;
        this.ID_nhanVien = ID_nhanVien;
        this.ID_vouCher = ID_vouCher;
        this.ngayTao = ngayTao;
        this.tongTien = tongTien;
        this.tenKhachHang = tenKhachHang;
        this.soDienThoaiKhachHang = soDienThoaiKhachHang;
        this.tenNhanVien = tenNhanVien;
        this.trangThai = trangThai;
        this.soTienGiam = soTienGiam;
    }

    public int getID_hoaDon() {
        return ID_hoaDon;
    }

    public void setID_hoaDon(int ID_hoaDon) {
        this.ID_hoaDon = ID_hoaDon;
    }

    public int getID_khachHang() {
        return ID_khachHang;
    }

    public void setID_khachHang(int ID_khachHang) {
        this.ID_khachHang = ID_khachHang;
    }

    public int getID_nhanVien() {
        return ID_nhanVien;
    }

    public void setID_nhanVien(int ID_nhanVien) {
        this.ID_nhanVien = ID_nhanVien;
    }

    public int getID_vouCher() {
        return ID_vouCher;
    }

    public void setID_vouCher(int ID_vouCher) {
        this.ID_vouCher = ID_vouCher;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public String getTongTien() {
        return tongTien;
    }

    public void setTongTien(String tongTien) {
        this.tongTien = tongTien;
    }

    public String getTenKhachHang() {
        return tenKhachHang;
    }

    public void setTenKhachHang(String tenKhachHang) {
        this.tenKhachHang = tenKhachHang;
    }

    public String getSoDienThoaiKhachHang() {
        return soDienThoaiKhachHang;
    }

    public void setSoDienThoaiKhachHang(String soDienThoaiKhachHang) {
        this.soDienThoaiKhachHang = soDienThoaiKhachHang;
    }

    public String getTenNhanVien() {
        return tenNhanVien;
    }

    public void setTenNhanVien(String tenNhanVien) {
        this.tenNhanVien = tenNhanVien;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public String getSoTienGiam() {
        return soTienGiam;
    }

    public void setSoTienGiam(String soTienGiam) {
        this.soTienGiam = soTienGiam;
    }

    
    
}
