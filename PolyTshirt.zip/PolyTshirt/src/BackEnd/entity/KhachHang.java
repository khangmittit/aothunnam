/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BackEnd.entity;

import java.util.Date;

/**
 *
 * @author Khang
 */
public class KhachHang {
    private int ID_khachHang;
    private String maKhachHang;
    private String hoVaTen;
    private String ngaySinh;         
    private String gioiTinh;
    private String soDienThoai;
    private String diaChi;
    private String trangThai;

    public KhachHang() {}

    public KhachHang(int ID_khachHang, String maKhachHang, String hoVaTen, String ngaySinh, String gioiTinh, 
                     String soDienThoai, String diaChi, String trangThai) {
        this.ID_khachHang = ID_khachHang;
        this.maKhachHang = maKhachHang;
        this.hoVaTen = hoVaTen;
        this.ngaySinh = ngaySinh;
        this.gioiTinh = gioiTinh;
        this.soDienThoai = soDienThoai;
        this.diaChi = diaChi;
        this.trangThai = trangThai;
    }

    // Getters và Setters cho từng thuộc tính
    public int getID_khachHang() { return ID_khachHang; }
    public void setID_khachHang(int ID_khachHang) { this.ID_khachHang = ID_khachHang; }

    public String getMaKhachHang() { return maKhachHang; }
    public void setMaKhachHang(String maKhachHang) { this.maKhachHang = maKhachHang; }

    public String getHoVaTen() { return hoVaTen; }
    public void setHoVaTen(String hoVaTen) { this.hoVaTen = hoVaTen; }

    public String getNgaySinh() { return ngaySinh; }
    public void setNgaySinh(String ngaySinh) { this.ngaySinh = ngaySinh; }

    public String getGioiTinh() { return gioiTinh; }
    public void setGioiTinh(String gioiTinh) { this.gioiTinh = gioiTinh; }

    public String getSoDienThoai() { return soDienThoai; }
    public void setSoDienThoai(String soDienThoai) { this.soDienThoai = soDienThoai; }

    public String getDiaChi() { return diaChi; }
    public void setDiaChi(String diaChi) { this.diaChi = diaChi; }

    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }
}
