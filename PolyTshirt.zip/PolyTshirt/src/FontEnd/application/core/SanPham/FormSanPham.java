/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package FontEnd.application.core.SanPham;
    import BackEnd.entity.SanPham;
import BackEnd.entity.SanPhamChiTiet;
import BackEnd.entity.ThuongHieu;
import BackEnd.entity.XuatXu;
    import BackEnd.service.SanPhamChiTietService;
    import BackEnd.service.SanPhamService;
    import java.util.ArrayList;
    import java.util.List;
    import java.util.function.BiFunction;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
    import javax.swing.JTable;
    import javax.swing.table.DefaultTableModel;


/**
 *
 * @author Khang
 */
public class FormSanPham extends javax.swing.JPanel {
    DefaultTableModel model = new DefaultTableModel();
    private DefaultTableModel modelsp = new DefaultTableModel();
    private final SanPhamService spservice = new SanPhamService();
    ArrayList<SanPham> listSanPham = spservice.getALLSp();
    SanPhamService sanPhamService = new SanPhamService();
    SanPhamChiTietService sanPhamChiTietService = new SanPhamChiTietService();
    ArrayList<SanPhamChiTiet> listSanPhamChiTiet = sanPhamChiTietService.getALLSanPhamChiTiet();
    private int indexHDS;
//    XuatXuService xuatXuService = new XuatXuService();
//    KichThuocService kichThuocService = new KichThuocService();
//    MauSacService mauSacService = new MauSacService();
    /**
     * Creates new form FormSanPham
     */
    public FormSanPham() {
        initComponents();
        sanPhamService = new SanPhamService();
        fillToTableSanPham();
        loadComboBoxData();
        loatdate(listSanPham);
//        fillToTableSanPhamChiTiet();// đẩy dữ liệu sang bảng sản phẩm chi tiết
//        listSanPhamCT = (ArrayList<SanPhamChiTiet>) SPCTService.selectAll();
//        LocByCombobox();
    }
    public void fillToTableSanPham() {
        fillToTable(tblSanPham, sanPhamService.getALLSp(), (s, i) -> new Object[]{i, s.getMaSanPham(), s.getTenSanPham(), s.getTenThuongHieu(), s.getTenXuatXu(), s.getSoLuong(), s.getTrangThai()});
    }
    
    private <T> void fillToTable(JTable table, List<T> list, BiFunction<T, Integer, Object[]> rowMapper) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);
        int i = 1;
        for (T item : list) {
            model.addRow(rowMapper.apply(item, i++));
        }
        table.setModel(model);
    }
    
//    public void fillToTableSanPhamChiTiet() {
//        fillToTable(tblSPCT, sanPhamChiTietService.getALLSanPhamChiTiet(), (s, i) -> new Object[]{s.getIdChiTietSanPham()});
//    }
    
    public void clearFormSP() {
        txtMaSanPham.setText("");
        txtTenSanPham.setText("");
        txtSoLuong1.setText("");
        cboThuongHieu.setSelectedIndex(0);
        cboXuatXu.setSelectedIndex(0);
    }
   public void ReadToTable() {
        try {
                int index = tblSanPham.getSelectedRow();

                if (index == -1) {
                    return;
                }

                SanPham sanPham = listSanPham.get(index);

                txtMaSP.setText(sanPham.getMaSanPham());
                txtTenSp.setText(sanPham.getTenSanPham());
                txtSoLuong.setText(String.valueOf(sanPham.getSoLuong()));
                cboThuongHieu.setSelectedItem(equals(sanPham.getTenThuongHieu()));
                cboXuatXu.setSelectedItem(equals(sanPham.getTenXuatXu()));


        } catch (Exception e) {
            e.printStackTrace(); // In lỗi nếu có
        }
}
   private void showTableSP(List<SanPham> listsp) {
        modelsp.setRowCount(0);
        int i = 1;
        int row = tblSanPham.getSelectedRow();
        String maSP = tblSanPham.getValueAt(row, 0).toString();
        listsp = spservice.getSanPhamByMa(maSP);
        for (SanPham sp : listsp) {
            modelsp.addRow(new Object[]{sp.getMaSanPham(), sp.getTenSanPham(), sp.getSoLuong(), sp.getTenThuongHieu(), sp.getTenXuatXu()});
        }
    }
   
   private void loadComboBoxData() {
    // Tải dữ liệu Thương hiệu
    ArrayList<ThuongHieu> thuongHieuList = sanPhamService.getThuongHieuFromDB(); // Lấy danh sách Thương hiệu từ dịch vụ
    cboThuongHieu.removeAllItems(); // Xóa tất cả các mục cũ trong ComboBox
    for (ThuongHieu thuongHieu : thuongHieuList) {
        cboThuongHieu.addItem(thuongHieu.getTenThuongHieu()); // Thêm tên thương hiệu vào ComboBox
    }

    // Tải dữ liệu Xuất xứ
    ArrayList<XuatXu> xuatXuList = sanPhamService.getXuatXuFromDB(); // Lấy danh sách Xuất xứ từ dịch vụ
    cboXuatXu.removeAllItems(); // Xóa tất cả các mục cũ trong ComboBox
    for (XuatXu xuatXu : xuatXuList) {
        cboXuatXu.addItem(xuatXu.getTenXuatXu()); // Thêm tên xuất xứ vào ComboBox
    }
}

  private void setComboBoxSelection(JComboBox<String> comboBox, String item) {
    if (item != null && !item.isEmpty()) {
        for (int i = 0; i < comboBox.getItemCount(); i++) {
            if (comboBox.getItemAt(i).equals(item)) {
                comboBox.setSelectedIndex(i); // Chọn mục trong ComboBox
                return; // Dừng vòng lặp khi tìm thấy
            }
        }
    }
}
  public void loatdate(ArrayList<SanPham> list) {
        model = (DefaultTableModel) tblSanPham.getModel();
        model.setRowCount(0);
        int i = 1;
        for (SanPham sp : list) {
                model.addRow(new Object[]{i, sp.getMaSanPham(), sp.getTenSanPham(), sp.getTenThuongHieu(), sp.getTenXuatXu(), sp.getSoLuong()});

    }
  }
  public void loatdate1() {
        model = (DefaultTableModel) tblSanPham.getModel();
        model.setRowCount(0);
        ArrayList<SanPham> list = sanPhamService.getALLSp();
        int i = 0;
        for (SanPham s : list) {
                model.addRow(new Object[]{
                    i, s.getMaSanPham(), s.getTenSanPham(), s.getTenThuongHieu(), s.getTenXuatXu(), s.getSoLuong()
                });
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        TpSanPham = new javax.swing.JTabbedPane();
        Sp = new javax.swing.JPanel();
        in = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtMaSanPham = new javax.swing.JLabel();
        txtTenSanPham = new javax.swing.JTextField();
        btnThemSanPham = new javax.swing.JButton();
        btnCapNhatSanPham = new javax.swing.JButton();
        btnXoaSanPham = new javax.swing.JButton();
        BtnClear = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cboThuongHieu = new javax.swing.JComboBox<>();
        cboXuatXu = new javax.swing.JComboBox<>();
        txtSoLuong1 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        out = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        JScroll1 = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        cboLocThuongHieu = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        cboLocXuatXu = new javax.swing.JComboBox<>();
        Spct = new javax.swing.JPanel();
        inSpct = new javax.swing.JPanel();
        BtnThemSoLuong = new javax.swing.JButton();
        btnBotSoLuong = new javax.swing.JButton();
        cbbKichCo3 = new javax.swing.JLabel();
        cboSize = new javax.swing.JComboBox<>();
        cbbKichCo1 = new javax.swing.JLabel();
        cbbKichCo = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtSoLuong = new javax.swing.JTextField();
        txtGiaBan = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        cboMauSac = new javax.swing.JComboBox<>();
        txtTenSp = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtMaSPCT = new javax.swing.JLabel();
        cboChatLieu = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        txtMaSP = new javax.swing.JLabel();
        outSpct = new javax.swing.JPanel();
        cboLocTH = new javax.swing.JComboBox<>();
        cboLocSize = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtThuocTinh = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblSPCT = new javax.swing.JTable();
        jLabel15 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        cboLocMauSac = new javax.swing.JComboBox<>();
        button = new javax.swing.JPanel();
        btnThemSPCT = new javax.swing.JButton();
        btnSuaSPCT = new javax.swing.JButton();
        btnXoaSPCT = new javax.swing.JButton();
        btnClearSPCT = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(1154, 634));

        jPanel1.setMaximumSize(new java.awt.Dimension(1142, 622));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("SẢN PHẨM");
        jLabel7.setMaximumSize(new java.awt.Dimension(76, 17));
        jLabel7.setMinimumSize(new java.awt.Dimension(76, 17));
        jLabel7.setPreferredSize(new java.awt.Dimension(76, 17));

        Sp.setPreferredSize(new java.awt.Dimension(750, 481));

        in.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        in.setPreferredSize(new java.awt.Dimension(1104, 156));

        jLabel4.setText("MÃ SẢN PHẨM");

        jLabel3.setText("TÊN SẢN PHẨM");

        txtMaSanPham.setText("MaSP");

        txtTenSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTenSanPhamActionPerformed(evt);
            }
        });

        btnThemSanPham.setText("THÊM MỚI");
        btnThemSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemSanPhamActionPerformed(evt);
            }
        });

        btnCapNhatSanPham.setText("CẬP NHẬT");
        btnCapNhatSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCapNhatSanPhamActionPerformed(evt);
            }
        });

        btnXoaSanPham.setText("XÓA");
        btnXoaSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaSanPhamActionPerformed(evt);
            }
        });

        BtnClear.setText("LÀM MỚI");
        BtnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnClearActionPerformed(evt);
            }
        });

        jLabel1.setText("Thương hiệu");

        jLabel2.setText("Xuất xứ");

        cboThuongHieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboThuongHieuActionPerformed(evt);
            }
        });

        cboXuatXu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboXuatXuActionPerformed(evt);
            }
        });

        txtSoLuong1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSoLuong1ActionPerformed(evt);
            }
        });

        jLabel14.setText("Số lượng");

        javax.swing.GroupLayout inLayout = new javax.swing.GroupLayout(in);
        in.setLayout(inLayout);
        inLayout.setHorizontalGroup(
            inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel14)
                    .addGroup(inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtSoLuong1, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                    .addComponent(txtMaSanPham)
                    .addComponent(txtTenSanPham))
                .addGap(27, 27, 27)
                .addGroup(inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cboThuongHieu, 0, 146, Short.MAX_VALUE)
                    .addComponent(cboXuatXu, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(btnCapNhatSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(inLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btnThemSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(27, 27, 27)
                .addGroup(inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(BtnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnXoaSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        inLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {BtnClear, btnCapNhatSanPham, btnThemSanPham, btnXoaSanPham});

        inLayout.setVerticalGroup(
            inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtMaSanPham))
                .addGap(18, 18, 18)
                .addGroup(inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtTenSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(cboThuongHieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnThemSanPham)
                    .addComponent(btnXoaSanPham))
                .addGap(16, 16, 16)
                .addGroup(inLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(txtSoLuong1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(cboXuatXu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCapNhatSanPham)
                    .addComponent(BtnClear))
                .addContainerGap(44, Short.MAX_VALUE))
        );

        inLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {BtnClear, btnCapNhatSanPham, btnThemSanPham, btnXoaSanPham});

        inLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {cboThuongHieu, cboXuatXu, txtTenSanPham});

        out.setBorder(javax.swing.BorderFactory.createTitledBorder("Thông tin sản phẩm"));
        out.setPreferredSize(new java.awt.Dimension(1101, 451));

        jLabel5.setText("Tìm Kiếm");

        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });

        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã Sản Phẩm", "Tên Sản Phẩm", "Thương hiệu", "Xuất xứ", "Số lượng"
            }
        ));
        tblSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSanPhamMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tblSanPhamMouseEntered(evt);
            }
        });
        JScroll1.setViewportView(tblSanPham);

        jLabel16.setText("Thương hiệu");

        cboLocThuongHieu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tất cả", "Thương hiệu A", "Thương hiệu B", "Thương hiệu C", "Thương hiệu D", "Thương hiệu E" }));
        cboLocThuongHieu.setName(""); // NOI18N
        cboLocThuongHieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboLocThuongHieuActionPerformed(evt);
            }
        });

        jLabel17.setText("Xuất xứ");

        cboLocXuatXu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Bộ lọc" }));
        cboLocXuatXu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboLocXuatXuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout outLayout = new javax.swing.GroupLayout(out);
        out.setLayout(outLayout);
        outLayout.setHorizontalGroup(
            outLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(outLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cboLocThuongHieu, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jLabel17)
                .addGap(18, 18, 18)
                .addComponent(cboLocXuatXu, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
            .addGroup(outLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(JScroll1)
                .addContainerGap())
        );
        outLayout.setVerticalGroup(
            outLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(outLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(outLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(cboLocThuongHieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17)
                    .addComponent(cboLocXuatXu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(JScroll1, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
                .addGap(13, 13, 13))
        );

        javax.swing.GroupLayout SpLayout = new javax.swing.GroupLayout(Sp);
        Sp.setLayout(SpLayout);
        SpLayout.setHorizontalGroup(
            SpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SpLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(out, javax.swing.GroupLayout.DEFAULT_SIZE, 837, Short.MAX_VALUE)
                    .addComponent(in, javax.swing.GroupLayout.DEFAULT_SIZE, 837, Short.MAX_VALUE))
                .addContainerGap())
        );
        SpLayout.setVerticalGroup(
            SpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SpLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(in, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(out, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1066, Short.MAX_VALUE))
        );

        in.getAccessibleContext().setAccessibleName("SẢN PHẨM");

        TpSanPham.addTab("Sản Phẩm", Sp);
        Sp.getAccessibleContext().setAccessibleName("");

        Spct.setPreferredSize(new java.awt.Dimension(1130, 554));

        inSpct.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        inSpct.setPreferredSize(new java.awt.Dimension(712, 291));

        BtnThemSoLuong.setText("+");
        BtnThemSoLuong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnThemSoLuongActionPerformed(evt);
            }
        });

        btnBotSoLuong.setText("-");
        btnBotSoLuong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBotSoLuongActionPerformed(evt);
            }
        });

        cbbKichCo3.setText("Chất liệu");

        cboSize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboSizeActionPerformed(evt);
            }
        });

        cbbKichCo1.setText("Màu sắc");

        cbbKichCo.setText("Size");

        jLabel12.setText("Số lượng");

        jLabel11.setText("Giá");

        jLabel10.setText("Tên sản phẩm");

        jLabel13.setText("Mã SPCT:");

        txtMaSPCT.setText("SPCT0001");

        jLabel19.setText("Mã SP:");

        txtMaSP.setText("SP0001");

        javax.swing.GroupLayout inSpctLayout = new javax.swing.GroupLayout(inSpct);
        inSpct.setLayout(inSpctLayout);
        inSpctLayout.setHorizontalGroup(
            inSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inSpctLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(inSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel13)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addGap(18, 18, 18)
                .addGroup(inSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtGiaBan)
                    .addComponent(txtTenSp)
                    .addGroup(inSpctLayout.createSequentialGroup()
                        .addGroup(inSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inSpctLayout.createSequentialGroup()
                                .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(BtnThemSoLuong)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnBotSoLuong))
                            .addComponent(txtMaSPCT, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(32, 32, 32)
                .addGroup(inSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cbbKichCo)
                    .addComponent(cbbKichCo3)
                    .addComponent(cbbKichCo1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19))
                .addGap(18, 18, 18)
                .addGroup(inSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboSize, 0, 177, Short.MAX_VALUE)
                    .addComponent(cboChatLieu, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cboMauSac, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(59, 59, 59))
        );
        inSpctLayout.setVerticalGroup(
            inSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inSpctLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(inSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txtMaSPCT)
                    .addComponent(jLabel19)
                    .addComponent(txtMaSP))
                .addGap(31, 31, 31)
                .addGroup(inSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtTenSp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbbKichCo3)
                    .addComponent(cboChatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(inSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtGiaBan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbbKichCo)
                    .addComponent(cboSize, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(inSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BtnThemSoLuong)
                    .addComponent(btnBotSoLuong)
                    .addComponent(cbbKichCo1)
                    .addComponent(cboMauSac, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        inSpctLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {BtnThemSoLuong, btnBotSoLuong, cboChatLieu, cboMauSac, cboSize, txtGiaBan, txtSoLuong, txtTenSp});

        outSpct.setBorder(javax.swing.BorderFactory.createTitledBorder("Thông tin sản phẩm chi tiết"));
        outSpct.setPreferredSize(new java.awt.Dimension(1233, 216));

        cboLocTH.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));

        jLabel8.setText("Tìm kiếm");

        jLabel9.setText("Thương hiệu");

        tblSPCT.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã SPCT", "Tên SP", "Giá", "Số lượng", "Chất liệu", "Màu sắc", "Size"
            }
        ));
        jScrollPane3.setViewportView(tblSPCT);

        jLabel15.setText("size");

        jLabel18.setText("Màu sắc");

        cboLocMauSac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboLocMauSacActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout outSpctLayout = new javax.swing.GroupLayout(outSpct);
        outSpct.setLayout(outSpctLayout);
        outSpctLayout.setHorizontalGroup(
            outSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(outSpctLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel8)
                .addGap(27, 27, 27)
                .addComponent(txtThuocTinh, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cboLocTH, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cboLocSize, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cboLocMauSac, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, outSpctLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 797, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(135, 135, 135))
        );
        outSpctLayout.setVerticalGroup(
            outSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(outSpctLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(outSpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtThuocTinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(cboLocTH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboLocSize, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(jLabel18)
                    .addComponent(cboLocMauSac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        button.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        button.setPreferredSize(new java.awt.Dimension(180, 176));

        btnThemSPCT.setText("Thêm");

        btnSuaSPCT.setText("Sửa");

        btnXoaSPCT.setText("Xoá");

        btnClearSPCT.setText("Làm mới");
        btnClearSPCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearSPCTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout buttonLayout = new javax.swing.GroupLayout(button);
        button.setLayout(buttonLayout);
        buttonLayout.setHorizontalGroup(
            buttonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(buttonLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(buttonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnClearSPCT)
                    .addGroup(buttonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btnXoaSPCT)
                        .addComponent(btnSuaSPCT)
                        .addComponent(btnThemSPCT)))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        buttonLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnClearSPCT, btnSuaSPCT, btnThemSPCT, btnXoaSPCT});

        buttonLayout.setVerticalGroup(
            buttonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(buttonLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(btnThemSPCT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSuaSPCT)
                .addGap(18, 18, 18)
                .addComponent(btnXoaSPCT)
                .addGap(18, 18, 18)
                .addComponent(btnClearSPCT)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        buttonLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnClearSPCT, btnSuaSPCT, btnThemSPCT, btnXoaSPCT});

        javax.swing.GroupLayout SpctLayout = new javax.swing.GroupLayout(Spct);
        Spct.setLayout(SpctLayout);
        SpctLayout.setHorizontalGroup(
            SpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SpctLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(SpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(outSpct, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(SpctLayout.createSequentialGroup()
                        .addComponent(inSpct, javax.swing.GroupLayout.PREFERRED_SIZE, 654, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(button, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SpctLayout.setVerticalGroup(
            SpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SpctLayout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .addGroup(SpctLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(inSpct, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                    .addComponent(button, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(outSpct, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1076, Short.MAX_VALUE))
        );

        TpSanPham.addTab("Sản Phẩm Chi Tiết", Spct);
        Spct.getAccessibleContext().setAccessibleName("");
        Spct.getAccessibleContext().setAccessibleDescription("");
        Spct.getAccessibleContext().setAccessibleParent(Spct);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(18, Short.MAX_VALUE)
                    .addComponent(TpSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 849, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(132, 132, 132)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1786, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(27, 27, 27)
                    .addComponent(TpSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 1658, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(124, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 862, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 292, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtTenSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTenSanPhamActionPerformed
      
    }//GEN-LAST:event_txtTenSanPhamActionPerformed

    private void btnThemSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemSanPhamActionPerformed
    // Lấy dữ liệu từ các trường
        String tenSanPham = txtTenSanPham.getText().trim();
        int soLuong = 0;  // Khởi tạo giá trị mặc định là 0
        String soLuongStr = txtSoLuong1.getText().trim();
        String tenThuongHieu = (String) cboThuongHieu.getSelectedItem();
        String tenXuatXu = (String) cboXuatXu.getSelectedItem();

        // Kiểm tra giá trị Số lượng có phải là một số hợp lệ không
        
            soLuong = Integer.parseInt(soLuongStr);  // Chuyển đổi giá trị từ chuỗi sang số nguyên
        
        String maSanPham = sanPhamService.generateNewMaSanPham();

        // Gọi service để thêm sản phẩm
        SanPham sanPham = new SanPham();
        sanPham.setMaSanPham(maSanPham);  // Sử dụng mã sản phẩm tự động
        sanPham.setTenSanPham(tenSanPham);
        sanPham.setSoLuong(soLuong);
        sanPham.setTenThuongHieu(tenThuongHieu);
        sanPham.setTenXuatXu(tenXuatXu);

        boolean isAdded = sanPhamService.themSanPham(sanPham);  // Gọi phương thức thêm sản phẩm

        if (isAdded) {
            JOptionPane.showMessageDialog(this, "Sản phẩm đã được thêm thành công.");
            // Cập nhật lại bảng danh sách sản phẩm
            showTableSP(sanPhamService.getALLSp());
        } else {
            JOptionPane.showMessageDialog(this, "Có lỗi khi thêm sản phẩm.");
        }


        
    }//GEN-LAST:event_btnThemSanPhamActionPerformed

    private void btnXoaSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaSanPhamActionPerformed

    }//GEN-LAST:event_btnXoaSanPhamActionPerformed

    private void btnCapNhatSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCapNhatSanPhamActionPerformed

    }//GEN-LAST:event_btnCapNhatSanPhamActionPerformed

    private void BtnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnClearActionPerformed
        clearFormSP();
        fillToTableSanPham();
    }//GEN-LAST:event_BtnClearActionPerformed

    private void BtnThemSoLuongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnThemSoLuongActionPerformed

    }//GEN-LAST:event_BtnThemSoLuongActionPerformed

    private void btnBotSoLuongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBotSoLuongActionPerformed

    }//GEN-LAST:event_btnBotSoLuongActionPerformed

    private void cboSizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboSizeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboSizeActionPerformed

    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemActionPerformed

    private void tblSanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSanPhamMouseClicked
//    int selectedRow = tblSanPham.getSelectedRow(); // Lấy dòng được chọn
//    if (selectedRow != -1) { // Nếu có dòng được chọn
//        try {
//            String maSanPham = tblSanPham.getValueAt(selectedRow, 1) != null
//                ? tblSanPham.getValueAt(selectedRow, 1).toString() : "";
//            String tenSanPham = tblSanPham.getValueAt(selectedRow, 2) != null
//                ? tblSanPham.getValueAt(selectedRow, 2).toString() : "";
//            String tenThuongHieu = tblSanPham.getValueAt(selectedRow, 3) != null
//                ? tblSanPham.getValueAt(selectedRow, 3).toString() : "";
//            String tenXuatXu = tblSanPham.getValueAt(selectedRow, 4) != null
//                ? tblSanPham.getValueAt(selectedRow, 4).toString() : "";
//            String soLuong = tblSanPham.getValueAt(selectedRow, 5) != null
//                ? tblSanPham.getValueAt(selectedRow, 5).toString() : "";
//
//            // Gán dữ liệu lên form
//            txtMaSanPham.setText(maSanPham);
//            txtTenSanPham.setText(tenSanPham);
//            cboThuongHieu.setSelectedItem(tenThuongHieu); // Đặt giá trị trong ComboBox
//            cboXuatXu.setSelectedItem(tenXuatXu);
//            txtSoLuong1.setText(soLuong);
//        } catch (Exception e) {
//            System.out.println("Lỗi khi load dữ liệu từ bảng lên form: " + e.getMessage());
//        }
//    }
//    System.out.println("Dữ liệu ComboBox Thương hiệu: " + cboThuongHieu.getItemCount());
//    System.out.println("Dữ liệu ComboBox Xuất xứ: " + cboXuatXu.getItemCount());
//    for (int i = 0; i < cboThuongHieu.getItemCount(); i++) {
//    System.out.println("Thương hiệu ComboBox: " + cboThuongHieu.getItemAt(i));
//        }
//
//        for (int i = 0; i < cboXuatXu.getItemCount(); i++) {
//            System.out.println("Xuất xứ ComboBox: " + cboXuatXu.getItemAt(i));
//        }

int selectedRow = tblSanPham.getSelectedRow(); // Lấy dòng được chọn
    if (selectedRow != -1) { // Nếu có dòng được chọn
        try {
            String maSanPham = tblSanPham.getValueAt(selectedRow, 1) != null
                ? tblSanPham.getValueAt(selectedRow, 1).toString() : "";
            String tenSanPham = tblSanPham.getValueAt(selectedRow, 2) != null
                ? tblSanPham.getValueAt(selectedRow, 2).toString() : "";
            String tenThuongHieu = tblSanPham.getValueAt(selectedRow, 3) != null
                ? tblSanPham.getValueAt(selectedRow, 3).toString() : "";
            String tenXuatXu = tblSanPham.getValueAt(selectedRow, 4) != null
                ? tblSanPham.getValueAt(selectedRow, 4).toString() : "";
            String soLuong1 = tblSanPham.getValueAt(selectedRow, 5) != null
                ? tblSanPham.getValueAt(selectedRow, 5).toString() : "";

            // Gán dữ liệu lên form
            txtMaSanPham.setText(maSanPham);
            txtTenSanPham.setText(tenSanPham);
            txtSoLuong1.setText(soLuong1);

            // Gán giá trị Thương hiệu vào ComboBox
            setComboBoxSelection(cboThuongHieu, tenThuongHieu);

            // Gán giá trị Xuất xứ vào ComboBox
            setComboBoxSelection(cboXuatXu, tenXuatXu);

        } catch (Exception e) {
            System.out.println("Lỗi khi load dữ liệu từ bảng lên form: " + e.getMessage());
        }
    }
        
    }//GEN-LAST:event_tblSanPhamMouseClicked

    private void cboLocMauSacActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboLocMauSacActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboLocMauSacActionPerformed

    private void txtSoLuong1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSoLuong1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSoLuong1ActionPerformed

    private void btnClearSPCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearSPCTActionPerformed
//        ClearFormSPCT();
    }//GEN-LAST:event_btnClearSPCTActionPerformed

    int previousRow = -1; // Biến để lưu dòng được chọn trước đó
    int clickCount = 0; // Biến để theo dõi số lần nhấp vào dòng hiện tại
    int idsp;
    private void tblSanPhamMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSanPhamMouseEntered
        // TODO add your handling code here:
//        ReadToTable();
    }//GEN-LAST:event_tblSanPhamMouseEntered

    private void cboThuongHieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboThuongHieuActionPerformed
        // TODO add your handling code here:
        cboThuongHieu.addActionListener(e -> filterTable());
    }//GEN-LAST:event_cboThuongHieuActionPerformed

    private void cboLocXuatXuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboLocXuatXuActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_cboLocXuatXuActionPerformed

    private void cboLocThuongHieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboLocThuongHieuActionPerformed
        // TODO add your handling code here:
        ArrayList<SanPham> listSpLoc = new ArrayList<>();
        for (SanPham sp : listSpLoc) {
            if (cboLocThuongHieu.getSelectedItem().equals(sp.getTenThuongHieu())) {
                listSpLoc.add(sp);
                loatdate(listSpLoc);
            }
        }
        String a = cboLocThuongHieu.getSelectedItem().toString();
        if (a.equals("Tất cả")) {
            loatdate1();
        }
    }//GEN-LAST:event_cboLocThuongHieuActionPerformed

    private void cboXuatXuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboXuatXuActionPerformed
        // TODO add your handling code here:
        cboXuatXu.addActionListener(e -> filterTable());
    }//GEN-LAST:event_cboXuatXuActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnClear;
    private javax.swing.JButton BtnThemSoLuong;
    private javax.swing.JScrollPane JScroll1;
    private javax.swing.JPanel Sp;
    private javax.swing.JPanel Spct;
    private javax.swing.JTabbedPane TpSanPham;
    private javax.swing.JButton btnBotSoLuong;
    private javax.swing.JButton btnCapNhatSanPham;
    private javax.swing.JButton btnClearSPCT;
    private javax.swing.JButton btnSuaSPCT;
    private javax.swing.JButton btnThemSPCT;
    private javax.swing.JButton btnThemSanPham;
    private javax.swing.JButton btnXoaSPCT;
    private javax.swing.JButton btnXoaSanPham;
    private javax.swing.JPanel button;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel cbbKichCo;
    private javax.swing.JLabel cbbKichCo1;
    private javax.swing.JLabel cbbKichCo3;
    private javax.swing.JComboBox<String> cboChatLieu;
    private javax.swing.JComboBox<String> cboLocMauSac;
    private javax.swing.JComboBox<String> cboLocSize;
    private javax.swing.JComboBox<String> cboLocTH;
    private javax.swing.JComboBox<String> cboLocThuongHieu;
    private javax.swing.JComboBox<String> cboLocXuatXu;
    private javax.swing.JComboBox<Object> cboMauSac;
    private javax.swing.JComboBox<Object> cboSize;
    private javax.swing.JComboBox<String> cboThuongHieu;
    private javax.swing.JComboBox<String> cboXuatXu;
    private javax.swing.JPanel in;
    private javax.swing.JPanel inSpct;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JPanel out;
    private javax.swing.JPanel outSpct;
    private javax.swing.JTable tblSPCT;
    private javax.swing.JTable tblSanPham;
    private javax.swing.JTextField txtGiaBan;
    private javax.swing.JLabel txtMaSP;
    private javax.swing.JLabel txtMaSPCT;
    private javax.swing.JLabel txtMaSanPham;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtSoLuong1;
    private javax.swing.JTextField txtTenSanPham;
    private javax.swing.JTextField txtTenSp;
    private javax.swing.JTextField txtThuocTinh;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables

    private void filterTable() {
    // Lấy giá trị thương hiệu và xuất xứ từ ComboBox
    String selectedThuongHieu = cboThuongHieu.getSelectedItem() != null ? cboThuongHieu.getSelectedItem().toString() : "";
    String selectedXuatXu = cboXuatXu.getSelectedItem() != null ? cboXuatXu.getSelectedItem().toString() : "";

    // Lọc dữ liệu theo thương hiệu và xuất xứ
    List<SanPham> filteredList = sanPhamService.getFilteredSanPham(selectedThuongHieu, selectedXuatXu);

    // Hiển thị kết quả lọc lên bảng
    modelsp.setRowCount(0);  // Xóa dữ liệu cũ trong bảng
    for (SanPham sp : filteredList) {
        modelsp.addRow(new Object[]{
            sp.getMaSanPham(), 
            sp.getTenSanPham(), 
            sp.getSoLuong(), 
            sp.getTenThuongHieu(), 
            sp.getTenXuatXu()
        });
    }
}
    
}

