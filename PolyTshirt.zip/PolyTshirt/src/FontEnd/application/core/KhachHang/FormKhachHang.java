/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package FontEnd.application.core.KhachHang;

import BackEnd.entity.KhachHang;
import BackEnd.model.NguoiDung;
import BackEnd.service.KhachHangService;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Khang
 */
public class FormKhachHang extends javax.swing.JPanel {
    DefaultTableModel model = new DefaultTableModel();
//    DefaultTableModel md = new DefaultTableModel();
    private final KhachHangService service = new KhachHangService();
    ArrayList<KhachHang> list = service.getAllKhachHang();
//    ArrayList<HoaDon> lstr = new ArrayList<>();

    /**
     * Creates new form FormKhachHang
     */
    public FormKhachHang() {
        initComponents();
        loadData(list);
    }
     int i;
    
    public void loadData(ArrayList<KhachHang> list) {
        model = (DefaultTableModel) tblKhachHang.getModel();
        model.setRowCount(0);  // Xóa toàn bộ dữ liệu trong bảng

        int i = 1;
        for (KhachHang kh : list) {

            model.addRow(new Object[]{
                i++,
                kh.getMaKhachHang(),
                kh.getHoVaTen(),
                kh.getSoDienThoai(),
                kh.getNgaySinh(),
                kh.getGioiTinh(),
                kh.getDiaChi(),
                kh.getTrangThai()
            });

        }
    }

    
    public void FillToTable() {
        try {
                int index = tblKhachHang.getSelectedRow();

                if (index == -1) {
                    return;
                }

                KhachHang khachHang = list.get(index);

                txtMa.setText(khachHang.getMaKhachHang());
                txtHoVaTen.setText(khachHang.getHoVaTen());
                txtSDT.setText(khachHang.getSoDienThoai());
                txtNgaySinh.setText(khachHang.getNgaySinh());

                String gioiTinh = khachHang.getGioiTinh();
                System.out.println("Giới tính: " + gioiTinh);  // In ra để kiểm tra giá trị
                rdoNam.setSelected(false);
                rdoNu.setSelected(false);
                if (gioiTinh != null) {
                    gioiTinh = gioiTinh.trim(); // Loại bỏ khoảng trắng thừa
                    if (gioiTinh.equalsIgnoreCase("Nam")) {
                        rdoNam.setSelected(true);
                    } else if (gioiTinh.equalsIgnoreCase("Nữ")) {
                        rdoNu.setSelected(true);
                    }
                }

                txtDia.setText(khachHang.getDiaChi());

                String trangThai = khachHang.getTrangThai();
                System.out.println("Trang thái: " + trangThai);  // In ra để kiểm tra giá trị
                rdoHoatDong.setSelected(false);
                rdoNgungHoatDong.setSelected(false);
                if (trangThai != null) {
                    trangThai = trangThai.trim(); // Loại bỏ khoảng trắng thừa
                    if (trangThai.equalsIgnoreCase("Hoạt động")) {
                        rdoHoatDong.setSelected(true);
                    } else if (trangThai.equalsIgnoreCase("Ngừng hoạt động")) {
                        rdoNgungHoatDong.setSelected(true);
                    }
                }

        } catch (Exception e) {
            e.printStackTrace(); // In lỗi nếu có
        }
}
    public void loadData1() {
        model = (DefaultTableModel) tblKhachHang.getModel();
        model.setRowCount(0);  // Xóa toàn bộ dữ liệu trong bảng
        ArrayList<KhachHang> list = service.getAllKhachHang();
        int a = 1;
        for (KhachHang kh : list) {

            model.addRow(new Object[]{
                a++,
                kh.getMaKhachHang(),
                kh.getHoVaTen(),
                kh.getSoDienThoai(),
                kh.getNgaySinh(),
                kh.getGioiTinh(),
                kh.getDiaChi(),
                kh.getTrangThai()
            });

        }
    }
    public void clean() {
        txtMa.setText(""); 
        txtHoVaTen.setText(""); 
        txtSDT.setText("");
        txtNgaySinh.setText("");

        rdoNam.setSelected(false);
        rdoNu.setSelected(false);
        txtDia.setText(""); 
        rdoHoatDong.setSelected(false);
        rdoNgungHoatDong.setSelected(false);
    }

    
    public KhachHang getModel() {
    KhachHang kh = new KhachHang();
    
    // Kiểm tra ID khách hàng trước khi chuyển đổi sang kiểu int
//    if (!txtId.getText().isEmpty()) {
//        kh.setID_khachHang(Integer.parseInt(txtId.getText()));  // Thiết lập ID khách hàng nếu có
//    }
    kh.setMaKhachHang(txtMa.getText()); 
    // Thiết lập tên khách hàng từ trường txtHo
    kh.setHoVaTen(txtHoVaTen.getText());  
    
    // Thiết lập địa chỉ từ trường txtDia
    kh.setDiaChi(txtDia.getText());       
    
    // Thiết lập email từ trường txtEmail
    kh.setNgaySinh(txtNgaySinh.getText());  
    
    // Thiết lập giới tính từ lựa chọn radio button
    if (rdoNam.isSelected()) {
            kh.setGioiTinh("Nam");
        } else if (rdoNu.isSelected()) {
            kh.setGioiTinh("Nữ");
        }   
    
    // Thiết lập số điện thoại từ trường txtSDT
    kh.setSoDienThoai(txtSDT.getText());          
    
    // Thiết lập trạng thái từ trường txtTrangThai
    if (rdoHoatDong.isSelected()) {
            kh.setTrangThai("Hoạt động");
        } else if (rdoNgungHoatDong.isSelected()) {
            kh.setTrangThai("Nghỉ việc");
        }  
    
    return kh;
}


//        public KhachHang getModelSua() {
//        KhachHang kh = new KhachHang();
//        kh.setID_khachHang(Integer.valueOf(txtId.getText()));
//        kh.setTenKhachHang(txtHo.getText());
//        kh.setDiaChi(txtDia.getText());
//        kh.setEmail(txtNgaySinh.getText());
//         if (rdNam.isSelected()) {
//            kh.setGioiTinh(true);
//        } else {
//            kh.setGioiTinh(false);
//        }
//        kh.setSDT(txtSDT.getText());
//        return kh;
//    }
//        public KhachHang getModelXoa() {
//        KhachHang kh = new KhachHang();
//        kh.setID_khachHang(Integer.valueOf(txtId.getText()));
//        kh.setTrangthai("0");
//        return kh;
//    }

    public void reset() {
        txtMa.setText("");
        txtHoVaTen.setText("");
        txtDia.setText("");
        txtNgaySinh.setText("");
        txtSDT.setText("");
    }
    
    public KhachHang getModelSua() {
        KhachHang kh = new KhachHang();
        kh.setHoVaTen(txtHoVaTen.getText());
        kh.setNgaySinh(txtNgaySinh.getText());
        kh.setSoDienThoai(txtSDT.getText());
        kh.setDiaChi(txtDia.getText());
//
//         if (rdodanglam.isSelected()) {
//            kh.setTrangThai(true);
//        } else {
//            kh.setTrangThai(false);
//        }
        return kh;
    }

    private boolean containsNumbers(String str) {
        for (char c : str.toCharArray()) {
            if (Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }
    
    private boolean containsSpecialCharacters(String input) {
    return input.matches(".*[!@#$%^&*(),.?\":{}|<>_+=-].*");
    }

    public boolean check() {
        if (txtMa.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Không để trống Mã khách hàng");
            return false;
        } 
        txtHoVaTen.setText(txtHoVaTen.getText().trim());
        if (txtHoVaTen.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tên không được để trống");
            return false;
        }
        if (containsNumbers(txtHoVaTen.getText())) {
            JOptionPane.showMessageDialog(this, "Tên không được chứa số");
            return false;
        }
        if (containsSpecialCharacters(txtHoVaTen.getText())) {
            JOptionPane.showMessageDialog(this, "Tên không được chứa ký tự đặc biệt");
            return false;
        }
        if (txtNgaySinh.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Không để trống ngày sinh");
            return false;
        } 
        if (txtSDT.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Không để SDT trống");
            return false;
        } else if (txtSDT.getText().length() != 10) {
            JOptionPane.showMessageDialog(this, "Sai định dạng SDT");
            return false;
        } else if (!txtSDT.getText().matches("[0-9]+")) {
            JOptionPane.showMessageDialog(this, "Không được nhập chữ trong SDT");
            return false;
        } else if (!txtSDT.getText().startsWith("0")) {
            JOptionPane.showMessageDialog(this, "SDT phải bắt đầu bằng số 0");
            return false;
        }
        if (txtDia.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Không để Địa chỉ trống");
            return false;
        }
        if (txtDia.getText().startsWith(" ") || txtHoVaTen.getText().endsWith(" ")) {
            JOptionPane.showMessageDialog(this, "Địa chỉ không được để khoảng trống ở đầu hoặc cuối");
            return false;
        }
        return true;
    }

//    public void loatdate(ArrayList<KhachHang> list) {
//        model = (DefaultTableModel) TbHienthi.getModel();
//        model.setRowCount(0);
//        // int i = 0;
//        for (KhachHang kh : list) {
//            // i++;
//         
//                model.addRow(new Object[]{
//                    TbHienthi.getRowCount() + 1,
//                    kh.getID_khachHang(), kh.getTenKhachHang(), kh.getDiaChi(), kh.getEmail(), kh.isGioiTinh() == false ? "Nữ" : "Nam", kh.getSDT()});
//            
//        }
//    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtMa = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtHoVaTen = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtNgaySinh = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        rdoNam = new javax.swing.JRadioButton();
        rdoNu = new javax.swing.JRadioButton();
        jLabel6 = new javax.swing.JLabel();
        txtSDT = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtDia = new javax.swing.JTextField();
        btnThem1 = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnLamMoi = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtTimKiem1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblKhachHang = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        rdoHoatDong = new javax.swing.JRadioButton();
        rdoNgungHoatDong = new javax.swing.JRadioButton();

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Thông tin khách hàng");

        jLabel2.setText("Mã");

        jLabel3.setText("Họ tên :  ");

        jLabel4.setText("Ngày sinh:");

        jLabel5.setText("Giới tính:");

        buttonGroup1.add(rdoNam);
        rdoNam.setText("Nam");
        rdoNam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdoNamActionPerformed(evt);
            }
        });

        buttonGroup1.add(rdoNu);
        rdoNu.setText("Nữ");

        jLabel6.setText("SĐT:");

        jLabel7.setText("Địa chỉ");

        btnThem1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnThem1.setText("Thêm thông tin");
        btnThem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThem1ActionPerformed(evt);
            }
        });

        btnSua.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnSua.setText("Sửa thông tin");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnLamMoi.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLamMoi.setText("Làm mới");
        btnLamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setText("Thông tin khách hàng");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Tìm kiếm");

        txtTimKiem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiem1ActionPerformed(evt);
            }
        });

        tblKhachHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "Mã khách hàng", "Tên Khách hàng", "Số điện thoại", "Ngày sinh", "Giới tính", "Địa chỉ", "Trạng thái"
            }
        ));
        tblKhachHang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblKhachHangMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblKhachHang);

        jLabel10.setText("Trạng thái:");

        buttonGroup2.add(rdoHoatDong);
        rdoHoatDong.setText("Hoạt động");
        rdoHoatDong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdoHoatDongActionPerformed(evt);
            }
        });

        buttonGroup2.add(rdoNgungHoatDong);
        rdoNgungHoatDong.setText("Ngừng hoạt động");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtHoVaTen)
                            .addComponent(txtNgaySinh)
                            .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(58, 58, 58)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7)
                            .addComponent(jLabel10))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(rdoNam)
                                    .addGap(18, 18, 18)
                                    .addComponent(rdoNu))
                                .addComponent(txtSDT)
                                .addComponent(txtDia, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rdoHoatDong)
                                .addGap(18, 18, 18)
                                .addComponent(rdoNgungHoatDong))))
                    .addComponent(jLabel8)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(42, 42, 42)
                            .addComponent(jLabel9)
                            .addGap(26, 26, 26)
                            .addComponent(txtTimKiem1))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(47, 47, 47)
                            .addComponent(btnThem1)
                            .addGap(116, 116, 116)
                            .addComponent(btnSua)
                            .addGap(132, 132, 132)
                            .addComponent(btnLamMoi)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 719, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(69, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(rdoNam)
                    .addComponent(rdoNu))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtHoVaTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtNgaySinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(txtDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(rdoHoatDong)
                        .addComponent(rdoNgungHoatDong))
                    .addComponent(jLabel10))
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThem1)
                    .addComponent(btnSua)
                    .addComponent(btnLamMoi))
                .addGap(50, 50, 50)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtTimKiem1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(106, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void rdoNamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdoNamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdoNamActionPerformed

    private void txtTimKiem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiem1ActionPerformed
        // TODO add your handling code here:
        ArrayList<KhachHang> listKH = new ArrayList<>();
        for (KhachHang khachHang : list) {
            String id = txtTimKiem1.getText();
            String maKh = khachHang.getHoVaTen()+ "";
            if (maKh.equals(id)) {
                listKH.add(khachHang);

            }
            if (khachHang.getHoVaTen().startsWith(txtTimKiem1.getText())) {
                listKH.add(khachHang);
            }
            String timkiem = txtTimKiem1.getText();
            String masdt = khachHang.getSoDienThoai() + "";
            if (masdt.equals(timkiem)) {
                listKH.add(khachHang);
            }
        }
        if (txtTimKiem1.getText().equals("")) {
            loadData1();
        } else {

            loadData(listKH);
        }
        reset();
    }//GEN-LAST:event_txtTimKiem1ActionPerformed

    private void btnLamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiActionPerformed
        // TODO add your handling code here:
        reset();
    }//GEN-LAST:event_btnLamMoiActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
//        // TODO add your handling code here:
        if (check()) {
            int chon = JOptionPane.showConfirmDialog(this, "Bạn muốn sửa không", "", JOptionPane.YES_NO_OPTION);
            if (chon == JOptionPane.YES_OPTION) {
                Integer result = service.updateKhachHang(getModelSua());
                if (result != null && result > 0) {
                    JOptionPane.showMessageDialog(this, "Sửa thành công");
                } else {
                    JOptionPane.showMessageDialog(this, "Sửa thất bại");
                }
                loadData(list);
                clean();
            }

        }
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnThem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThem1ActionPerformed
        // TODO add your handling code here:
        if (check()) {
            int chon = JOptionPane.showConfirmDialog(this, "Bạn muốn thêm không", "", JOptionPane.YES_NO_OPTION);
            if (chon == JOptionPane.YES_OPTION) {
                service.addKhachHang(getModel());
                JOptionPane.showMessageDialog(this, "Thêm thành công");
                
                loadData1();
                clean();
            }else{
                JOptionPane.showMessageDialog(this, "Thêm thất bại");
            }
        }
    }//GEN-LAST:event_btnThem1ActionPerformed

    private void tblKhachHangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblKhachHangMouseClicked
//         TODO add your handling code here:
//        int index = tblKhachHang.getSelectedRow();
//        String id = tblKhachHang.getValueAt(index, 1).toString();
//        if (index == -1) {
//            return;
//        }
//        int i = 1;
//        md.setRowCount(0);
//        lstr = service.lienKetHoaDon(Integer.parseInt(id));
//        if (!lstr.isEmpty()) {
//            for (HoaDon hd : lstr) {
//                md.addRow(new Object[]{i++, hd.getId(), hd.getIdkh(), hd.getNgd(), hd.getTongTien(), hd.getTt()});
//            }
//        }
        FillToTable();
    }//GEN-LAST:event_tblKhachHangMouseClicked

    private void rdoHoatDongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdoHoatDongActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdoHoatDongActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLamMoi;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem1;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rdoHoatDong;
    private javax.swing.JRadioButton rdoNam;
    private javax.swing.JRadioButton rdoNgungHoatDong;
    private javax.swing.JRadioButton rdoNu;
    private javax.swing.JTable tblKhachHang;
    private javax.swing.JTextField txtDia;
    private javax.swing.JTextField txtHoVaTen;
    private javax.swing.JTextField txtMa;
    private javax.swing.JTextField txtNgaySinh;
    private javax.swing.JTextField txtSDT;
    private javax.swing.JTextField txtTimKiem1;
    // End of variables declaration//GEN-END:variables
}
