/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package FontEnd.application.core.NhanVien;

import BackEnd.connect.DBSqlConnection;
import BackEnd.model.NguoiDung;
import java.util.ArrayList;
import javax.swing.JComponent;
import javax.swing.table.DefaultTableModel;
import BackEnd.service.NguoiDungService;
import com.sun.jdi.connect.spi.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Khang
 */
public class FormNhanVien extends JComponent {

    private DefaultTableModel model = new DefaultTableModel();
    private DefaultTableModel dtm;
    private final NguoiDungService nguoiDungService = new NguoiDungService();
    ArrayList<NguoiDung> list = nguoiDungService.getAll();

    /**
     * Creates new form FormNhanVien
     */
    public FormNhanVien() {
        initComponents();
        loadData(list);
    }

    public void loadData(ArrayList<NguoiDung> list) {
        dtm = (DefaultTableModel) tblnguoidung.getModel();
        dtm.setRowCount(0);  // Xóa toàn bộ dữ liệu trong bảng

        int i = 1;
        for (NguoiDung nd : list) {

            dtm.addRow(new Object[]{
                i++,
                nd.getID_nhanVien(),
                nd.getTenNguoiDung(),
                nd.getNgaySinh(),
                nd.getSoDienThoai(),
                nd.getQueQuan(),
                nd.getEmail(),
                nd.getIdChucVu(),
                nd.getTrangThai()
            });

        }
    }

    public void loadData1() {
        dtm = (DefaultTableModel) tblnguoidung.getModel();
        dtm.setRowCount(0);  // Xóa toàn bộ dữ liệu trong bảng
        ArrayList<NguoiDung> list = nguoiDungService.getAll();
        int i = 1;
        for (NguoiDung nd : list) {

            dtm.addRow(new Object[]{
                i++,
                nd.getID_nhanVien(),
                nd.getTenNguoiDung(),
                nd.getNgaySinh(),
                nd.getSoDienThoai(),
                nd.getQueQuan(),
                nd.getEmail(),
                nd.getIdChucVu(),
                nd.getTrangThai()
            });

        }
    }

    public void filldate() {
        try {
            int index = tblnguoidung.getSelectedRow();

            if (index == -1) {
                return;
            }

            NguoiDung nguoiDung = list.get(index);

            txtten.setText(nguoiDung.getTenNguoiDung());
            txtngaysinh.setText(nguoiDung.getNgaySinh());
            txtsdt.setText(nguoiDung.getSoDienThoai());
            txtquequan.setText(nguoiDung.getQueQuan());
            txtemail.setText(nguoiDung.getEmail());

            String trangThai = nguoiDung.getTrangThai();
            System.out.println("Trang thái: " + trangThai);  // In ra để kiểm tra giá trị
            rdodanglam.setSelected(false);
            rdonghiviec.setSelected(false);
            if (trangThai != null) {
                trangThai = trangThai.trim(); // Loại bỏ khoảng trắng thừa
                if (trangThai.equalsIgnoreCase("Hoạt động")) {
                    rdodanglam.setSelected(true);
                } else if (trangThai.equalsIgnoreCase("Nghỉ việc")) {
                    rdonghiviec.setSelected(true);
                }
            }

            // Chọn chức vụ tương ứng trong cbbchucvu
            int idChucVu = nguoiDung.getIdChucVu();
            switch (idChucVu) {
                case 1:
                    cbbchucvu.setSelectedItem("Nhân viên bán hàng");
                    break;
                case 2:
                    cbbchucvu.setSelectedItem("Nhân viên kho");
                    break;
                case 3:
                    cbbchucvu.setSelectedItem("Nhân viên kỹ thuật");
                    break;
                case 4:
                    cbbchucvu.setSelectedItem("Nhân viên chăm sóc khách hàng");
                    break;
                case 5:
                    cbbchucvu.setSelectedItem("Quản lý");
                    break;
                default:
                    cbbchucvu.setSelectedItem("Không xác định");
                    break;
            }

        } catch (Exception e) {
            e.printStackTrace(); // In lỗi nếu có
        }
    }

    public void clean() {
        txtten.setText(""); // Xóa mã người dùng nếu có trường này
        txtsdt.setText(""); // Xóa tên người dùng
        txtemail.setText(""); // Xóa số điện thoại
        txtngaysinh.setText(""); // Xóa ngày sinh
        txtquequan.setText(""); // Xóa email

        // Đặt lại các radio button trạng thái (hoặc combo box, tùy theo giao diện)
        rdodanglam.setSelected(false);
        rdonghiviec.setSelected(false);

        // Đặt lại ComboBox chức vụ nếu có
        cbbchucvu.setSelectedIndex(-1);
    }

    public NguoiDung GETMODE() {
        NguoiDung nguoiDung = new NguoiDung();

        // Lấy giá trị từ ComboBox để xác định ID Chức vụ
        String chucVu = (String) cbbchucvu.getSelectedItem();  // Lấy giá trị từ ComboBox

        // Kiểm tra nếu người dùng không chọn chức vụ hợp lệ
        if (chucVu == null || chucVu.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Chức vụ không hợp lệ!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        switch (chucVu) {
            case "Nhân viên bán hàng":
                nguoiDung.setIdChucVu(1);
                break;
            case "Nhân viên kho":
                nguoiDung.setIdChucVu(2);
                break;
            case "Nhân viên kỹ thuật":
                nguoiDung.setIdChucVu(3);
                break;
            case "Nhân viên chăm sóc khách hàng":
                nguoiDung.setIdChucVu(4);
                break;
            case "Quản lý":
                nguoiDung.setIdChucVu(5);
                break;
            default:
                nguoiDung.setIdChucVu(0);  // Mặc định nếu không chọn được
                break;
        }

        // Lấy dữ liệu từ các trường nhập liệu
        nguoiDung.setTenNguoiDung(txtten.getText()); // Tên người dùng
        nguoiDung.setNgaySinh(txtngaysinh.getText());
        nguoiDung.setSoDienThoai(txtsdt.getText()); // Số điện thoại
        nguoiDung.setEmail(txtemail.getText()); // Email
        nguoiDung.setQueQuan(txtquequan.getText()); // Quê quán

        // Kiểm tra trạng thái hoạt động của người dùng
        if (rdodanglam.isSelected()) {
            nguoiDung.setTrangThai("Hoạt động");
        } else if (rdonghiviec.isSelected()) {
            nguoiDung.setTrangThai("Nghỉ việc");
        }

        return nguoiDung;
    }

    public NguoiDung getModelSua() {
        NguoiDung kh = new NguoiDung();
        kh.setTenNguoiDung(txtten.getText());
        kh.setNgaySinh(txtngaysinh.getText());
        kh.setSoDienThoai(txtsdt.getText());
        kh.setEmail(txtemail.getText());
        kh.setQueQuan(txtquequan.getText());
//
//         if (rdodanglam.isSelected()) {
//            kh.setTrangThai(true);
//        } else {
//            kh.setTrangThai(false);
//        }
        return kh;
    }

    private boolean containsNumbers(String str) {
        for (char c : str.toCharArray()) {
            if (Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }

    public boolean check() {
        txtten.setText(txtten.getText().trim());
        if (txtten.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tên không được để trống");
            return false;
        }
        String tenNguoiDung = txtten.getText().trim(); // Loại bỏ khoảng trắng ở đầu và cuối
//        if (tenNguoiDung.isEmpty()) {
//            JOptionPane.showMessageDialog(this, "Không để trống tên");
//            return false;
//        }

        if (tenNguoiDung.length() > 50) {
            JOptionPane.showMessageDialog(this, "Tên không được lớn hơn 50 ký tự");
            return false;
        }
        if (containsNumbers(tenNguoiDung)) {
            JOptionPane.showMessageDialog(this, "Tên không được chứa số");
            return false;
        }
        if (!tenNguoiDung.matches("[a-zA-ZÀ-ỹ\\s]+")) {
            JOptionPane.showMessageDialog(this, "Tên không được chứa ký tự đặc biệt");
            return false;
        }

// Kiểm tra ngày sinh
        String ngaySinh = txtngaysinh.getText().trim(); // Loại bỏ khoảng trắng ở đầu và cuối
        if (ngaySinh.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Không để trống ngày sinh");
            return false;
        }
        String ngaySinhPattern = "^\\d{4}-\\d{2}-\\d{2}$";
        if (!ngaySinh.matches(ngaySinhPattern)) {
            JOptionPane.showMessageDialog(this, "Sai định dạng ngày sinh. Vui lòng nhập theo định dạng yyyy-MM-dd");
            return false;
        }

// Kiểm tra tháng và ngày trong ngày sinh
        String[] dateComponents = ngaySinh.split("-");
        int year = Integer.parseInt(dateComponents[0]);
        int month = Integer.parseInt(dateComponents[1]);
        int day = Integer.parseInt(dateComponents[2]);
        if (month < 1 || month > 12) {
            JOptionPane.showMessageDialog(this, "Tháng không hợp lệ. Vui lòng nhập tháng từ 1 đến 12");
            return false;
        }
        if (day < 1 || day > 31) {
            JOptionPane.showMessageDialog(this, "Ngày không hợp lệ. Vui lòng nhập ngày từ 1 đến 31");
            return false;
        }

// Kiểm tra số điện thoại
        String sdt = txtsdt.getText().trim(); // Loại bỏ khoảng trắng ở đầu và cuối
        if (sdt.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Không để trống số điện thoại");
            return false;
        } else if (sdt.length() != 10) {
            JOptionPane.showMessageDialog(this, "Số điện thoại phải có đúng 10 ký tự");
            return false;
        } else if (!sdt.matches("[0-9]+")) {
            JOptionPane.showMessageDialog(this, "Số điện thoại không được chứa chữ");
            return false;
        } else if (!sdt.startsWith("0")) {
            JOptionPane.showMessageDialog(this, "Số điện thoại phải bắt đầu bằng '0'");
            return false;
        }

// Kiểm tra Email
        String email = txtemail.getText().trim(); // Loại bỏ khoảng trắng ở đầu và cuối
        if (!email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,3})$")) {
            JOptionPane.showMessageDialog(this, "Sai định dạng Email");
            return false;
        }

// Kiểm tra quê quán
        String queQuan = txtquequan.getText().trim(); // Loại bỏ khoảng trắng ở đầu và cuối
        if (queQuan.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Quê quán không được để trống");
            return false;
        }
        // Kiểm tra xem rdodanglam hay rdonghiviec được chọn
        boolean isDangLam = rdodanglam.isSelected();  // Kiểm tra nếu rdodanglam được chọn
        boolean isNghiViec = rdonghiviec.isSelected();  // Kiểm tra nếu rdonghiviec được chọn

// Kiểm tra nếu không có radio button nào được chọn
        if (!isDangLam && !isNghiViec) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn trạng thái làm việc (Đang làm hay Nghỉ việc)");
            return false;
        }

        return true;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtten = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtngaysinh = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtsdt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtemail = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtquequan = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        rdodanglam = new javax.swing.JRadioButton();
        rdonghiviec = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        cbbtrangthai = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        txttimkiem = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblnguoidung = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        cbbchucvu = new javax.swing.JComboBox<>();

        jLabel1.setText("Tên nhân viên");

        jLabel2.setText("Ngày sinh");

        jLabel3.setText("Số điện thoại");

        jLabel4.setText("Email");

        jLabel5.setText("Quê quán");

        txtquequan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtquequanActionPerformed(evt);
            }
        });

        jLabel6.setText("Trạng thái");

        rdodanglam.setText("Hoạt động");
        rdodanglam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdodanglamActionPerformed(evt);
            }
        });

        rdonghiviec.setText("Nghỉ việc");

        jButton1.setText("Thêm");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Mới");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Sửa");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setText("Thông tin");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel9.setText("Lọc : ");

        jLabel10.setText("Trạng thái");

        cbbtrangthai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Hoạt động", "Nghỉ việc" }));
        cbbtrangthai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbtrangthaiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbbtrangthai, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel9))
                .addGap(0, 17, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(cbbtrangthai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 25, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel12.setText("Tìm kiếm");

        txttimkiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txttimkiemKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(txttimkiem, javax.swing.GroupLayout.DEFAULT_SIZE, 268, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txttimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        tblnguoidung.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STT", "ID", "Tên người dùng", "Ngày sinh", "Số điện thoại", "Quê Quán", "Email", "ID chức vụ", "Trạng thái"
            }
        ));
        tblnguoidung.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblnguoidungMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblnguoidung);

        jButton4.setText("Nghỉ việc");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jButton4)
                .addGap(0, 78, Short.MAX_VALUE))
        );

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel8.setText("Thông tin người dùng");

        jLabel11.setText("Chức Vụ");

        cbbchucvu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nhân viên bán hàng", "Nhân viên kho", "Nhân viên kỹ thuật", "Nhân viên chăm sóc khách hàng", "Quản lý" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtten)
                            .addComponent(txtngaysinh)
                            .addComponent(txtquequan)
                            .addComponent(cbbchucvu, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(106, 106, 106)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton3))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtsdt, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtemail, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jButton2)
                                            .addComponent(rdodanglam))
                                        .addGap(18, 18, 18)
                                        .addComponent(rdonghiviec, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(91, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtten, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txtsdt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtemail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(txtngaysinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtquequan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(rdodanglam)
                    .addComponent(rdonghiviec))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cbbchucvu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1)
                    .addComponent(jButton3)
                    .addComponent(jButton2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtquequanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtquequanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtquequanActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        clean();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void tblnguoidungMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblnguoidungMouseClicked
        // TODO add your handling code here:
        filldate();
    }//GEN-LAST:event_tblnguoidungMouseClicked

    private void rdodanglamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdodanglamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdodanglamActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (check()) {
            int chon = JOptionPane.showConfirmDialog(this, "Bạn muốn thêm không ?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (chon == JOptionPane.YES_OPTION) {
                Integer result = nguoiDungService.ADD(GETMODE());

                if (result != null && result > 0) { // Kiểm tra nếu phương thức ADD thực thi thành công
                    JOptionPane.showMessageDialog(this, "Thêm thành công");
                    loadData1();
                    clean();
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm thất bại");
                }
            }
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        if (check()) {
            int chon = JOptionPane.showConfirmDialog(this, "Bạn muốn sửa không", "", JOptionPane.YES_NO_OPTION);
            if (chon == JOptionPane.YES_OPTION) {
                Integer result = nguoiDungService.update(getModelSua());
                if (result != null && result > 0) {
                    JOptionPane.showMessageDialog(this, "Sửa thành công");
                } else {
                    JOptionPane.showMessageDialog(this, "Sửa thất bại");
                }
                loadData(list);
                clean();
            }

        }


    }//GEN-LAST:event_jButton3ActionPerformed

    private void cbbtrangthaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbtrangthaiActionPerformed
        ArrayList<NguoiDung> listVT = new ArrayList<>();
        for (NguoiDung nv : list) {
            if (cbbtrangthai.getSelectedItem().equals(nv.getTrangThai())) {
                listVT.add(nv);
                loadData(listVT);
            }
        }
        String a = cbbtrangthai.getSelectedItem().toString();
        if (a.equals("Tất cả")) {
            loadData1();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_cbbtrangthaiActionPerformed

    private void txttimkiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txttimkiemKeyReleased
        ArrayList<NguoiDung> listNV = new ArrayList<>();
        String timkiem = txttimkiem.getText().trim(); // Lấy và loại bỏ khoảng trắng dư thừa

// Kiểm tra nếu có giá trị tìm kiếm
        if (!timkiem.isEmpty()) {
            for (NguoiDung nguoidung : list) {
                // Kiểm tra xem ID_nhanVien có trùng với giá trị tìm kiếm không
                if (String.valueOf(nguoidung.getID_nhanVien()).equals(timkiem)) {
                    listNV.add(nguoidung);
                }
            }
        }

// Nếu không có giá trị tìm kiếm, tải lại dữ liệu ban đầu
        if (timkiem.equals("")) {
            loadData1();
        } else {
            loadData(listNV); // Hiển thị danh sách tìm được
        }

        clean(); // Xóa các trường tìm kiếm hoặc thực hiện hành động khác sau khi tìm kiếm

        // TODO add your handling code here:
    }//GEN-LAST:event_txttimkiemKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbbchucvu;
    private javax.swing.JComboBox<String> cbbtrangthai;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rdodanglam;
    private javax.swing.JRadioButton rdonghiviec;
    private javax.swing.JTable tblnguoidung;
    private javax.swing.JTextField txtemail;
    private javax.swing.JTextField txtngaysinh;
    private javax.swing.JTextField txtquequan;
    private javax.swing.JTextField txtsdt;
    private javax.swing.JTextField txtten;
    private javax.swing.JTextField txttimkiem;
    // End of variables declaration//GEN-END:variables
}
