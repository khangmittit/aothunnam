/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BackEnd.entity;

import javax.swing.JTable;

/**
 *
 * @author Thien
 */
public class Table extends JTable{
    public Table(){
        
    }
}
